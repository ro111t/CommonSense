
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        // New-Gen Club App Palette
        base: 'var(--color-base)',
        surface: {
          DEFAULT: 'var(--color-surface)',
          mid: 'var(--color-surface-mid)',
          deep: 'var(--color-surface-deep)',
        },
        accent: {
          green: 'var(--color-green)',
          'green-bg': 'var(--color-green-bg)',
          'green-text': 'var(--color-green-text)',
          purple: 'var(--color-purple)',
          'purple-bg': 'var(--color-purple-bg)',
          'purple-text': 'var(--color-purple-text)',
          pink: 'var(--color-pink)',
          'pink-bg': 'var(--color-pink-bg)',
          'pink-text': 'var(--color-pink-text)',
          blue: 'var(--color-blue)',
          'blue-bg': 'var(--color-blue-bg)',
          'blue-text': 'var(--color-blue-text)',
          amber: 'var(--color-amber)',
          'amber-bg': 'var(--color-amber-bg)',
          'amber-text': 'var(--color-amber-text)',
          red: 'var(--color-red)',
          'red-bg': 'var(--color-red-bg)',
          'red-text': 'var(--color-red-text)',
        },
        ink: {
          DEFAULT: 'var(--color-text-primary)',
          secondary: 'var(--color-text-secondary)',
          muted: 'var(--color-text-muted)',
        },
        border: {
          DEFAULT: 'var(--color-border)',
          light: 'var(--color-border-light)',
        },
      },
    },
  },
  plugins: [],
}
