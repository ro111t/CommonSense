import React, { useState } from 'react';
import { AllInboxesScreen, sampleMembers, sampleProjects, sampleAnnouncements, samplePostings, sampleCalendarEvents } from './components/AllInboxesScreen';
import { MailboxesScreen } from './components/MailboxesScreen';
import { HomeScreen } from './components/HomeScreen';
import { AccountScreen } from './components/AccountScreen';
import { MemberProfileScreen } from './components/MemberProfileScreen';
import { ProjectDetailScreen } from './components/ProjectDetailScreen';
import { AnnouncementDetailScreen } from './components/AnnouncementDetailScreen';
import { PostingDetailScreen } from './components/PostingDetailScreen';
import { CalendarEventDetailScreen } from './components/CalendarEventDetailScreen';
import { InboxScreen } from './components/InboxScreen';
import { ConversationScreen } from './components/ConversationScreen';
import { ClubsAndSocietiesScreen } from './components/ClubsAndSocietiesScreen';
import type { Member } from './components/MemberProfileScreen';
import type { Project } from './components/ProjectDetailScreen';
import type { Announcement } from './components/AnnouncementDetailScreen';
import type { Posting } from './components/PostingDetailScreen';
import type { CalendarEvent } from './components/CalendarEventDetailScreen';
import type { Conversation } from './components/InboxScreen';
type Screen = 'home' | 'mailboxes' | 'account' | 'all-inboxes' | 'member-profile' | 'project-detail' | 'announcement-detail' | 'posting-detail' | 'calendar-detail' | 'inbox' | 'conversation' | 'clubs-societies';
export function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('mailboxes');
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [selectedPosting, setSelectedPosting] = useState<Posting | null>(null);
  const [selectedCalendarEvent, setSelectedCalendarEvent] = useState<CalendarEvent | null>(null);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const navProps = {
    onNavigateHome: () => setCurrentScreen('home'),
    onNavigateMailboxes: () => setCurrentScreen('mailboxes'),
    onNavigateAccount: () => setCurrentScreen('account')
  };
  return <>
      {currentScreen === 'home' && <HomeScreen onNavigateToInboxes={() => setCurrentScreen('all-inboxes')} {...navProps} />}

      {currentScreen === 'mailboxes' && <MailboxesScreen onNavigateToInboxes={() => setCurrentScreen('all-inboxes')} onNavigateToInbox={() => setCurrentScreen('inbox')} onNavigateHome={navProps.onNavigateHome} onNavigateAccount={navProps.onNavigateAccount} />}

      {currentScreen === 'account' && <AccountScreen {...navProps} onNavigateClubs={() => setCurrentScreen('clubs-societies')} />}

      {currentScreen === 'clubs-societies' && <ClubsAndSocietiesScreen onBack={() => setCurrentScreen('account')} />}

      {currentScreen === 'all-inboxes' && <AllInboxesScreen onBack={() => setCurrentScreen('mailboxes')} onViewMember={(m) => {
      setSelectedMember(m);
      setCurrentScreen('member-profile');
    }} onViewProject={(p) => {
      setSelectedProject(p);
      setCurrentScreen('project-detail');
    }} onViewAnnouncement={(a) => {
      setSelectedAnnouncement(a);
      setCurrentScreen('announcement-detail');
    }} onViewPosting={(p) => {
      setSelectedPosting(p);
      setCurrentScreen('posting-detail');
    }} onViewCalendarEvent={(e) => {
      setSelectedCalendarEvent(e);
      setCurrentScreen('calendar-detail');
    }} />}

      {currentScreen === 'inbox' && <InboxScreen onBack={() => setCurrentScreen('mailboxes')} onViewConversation={(conv) => {
      setSelectedConversation(conv);
      setCurrentScreen('conversation');
    }} />}

      {currentScreen === 'conversation' && selectedConversation && <ConversationScreen conversation={selectedConversation} onBack={() => setCurrentScreen('inbox')} />}

      {currentScreen === 'member-profile' && selectedMember && <MemberProfileScreen member={selectedMember} isAdmin={true} onBack={() => setCurrentScreen('all-inboxes')} />}

      {currentScreen === 'project-detail' && selectedProject && <ProjectDetailScreen project={selectedProject} onBack={() => setCurrentScreen('all-inboxes')} />}

      {currentScreen === 'announcement-detail' && selectedAnnouncement && <AnnouncementDetailScreen announcement={selectedAnnouncement} isAdmin={true} onBack={() => setCurrentScreen('all-inboxes')} />}

      {currentScreen === 'posting-detail' && selectedPosting && <PostingDetailScreen posting={selectedPosting} onBack={() => setCurrentScreen('all-inboxes')} />}

      {currentScreen === 'calendar-detail' && selectedCalendarEvent && <CalendarEventDetailScreen event={selectedCalendarEvent} onBack={() => setCurrentScreen('all-inboxes')} />}
    </>;
}