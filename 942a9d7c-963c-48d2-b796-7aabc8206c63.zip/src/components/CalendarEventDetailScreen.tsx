import React, { useState } from 'react';
import { ChevronLeftIcon, CalendarIcon, MapPinIcon, ClockIcon, UserIcon, CheckIcon, XIcon, MinusIcon, PlusCircleIcon, BuildingIcon } from 'lucide-react';
export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  dayOfWeek: string;
  time: string;
  endTime: string;
  location: string;
  building: string;
  organizer: string;
  organizerInitials: string;
  organizerColor: string;
  type: 'meeting' | 'deadline' | 'showcase' | 'election';
  description: string;
  color: string;
}
interface CalendarEventDetailScreenProps {
  event: CalendarEvent;
  onBack: () => void;
}
const typeLabels: Record<CalendarEvent['type'], string> = {
  meeting: 'Club Meeting',
  deadline: 'Deadline',
  showcase: 'Showcase Event',
  election: 'Election'
};
export function CalendarEventDetailScreen({
  event,
  onBack
}: CalendarEventDetailScreenProps) {
  const [rsvp, setRsvp] = useState<'accept' | 'maybe' | 'decline' | null>(null);
  const [addedToCalendar, setAddedToCalendar] = useState(false);
  const [mapTapped, setMapTapped] = useState(false);
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Nav */}
        <div className="flex items-center px-4 py-2 border-b" style={{
        backgroundColor: '#F0F2F5',
        borderColor: '#E5E7EB'
      }}>
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#FB7185'
        }}>
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Calendar</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none'
      }}>
          {/* iOS .ics style invitation card */}
          <div className="mx-4 mt-4 rounded-3xl overflow-hidden shadow-sm" style={{
          backgroundColor: '#FFFFFF'
        }}>
            {/* Color header band */}
            <div className="h-2 w-full" style={{
            backgroundColor: event.color
          }} />

            <div className="px-5 pt-4 pb-5">
              {/* Type badge */}
              <span className="inline-block text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full mb-3" style={{
              backgroundColor: event.color + '20',
              color: event.color
            }}>
                {typeLabels[event.type]}
              </span>

              {/* Title */}
              <h1 className="text-[22px] font-bold text-gray-900 leading-snug mb-5">
                {event.title}
              </h1>

              {/* Date/time row */}
              <div className="flex items-start gap-3 mb-4">
                {/* Calendar date block */}
                <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 shadow-sm border border-gray-100">
                  <div className="h-3 w-full" style={{
                  backgroundColor: event.color
                }} />
                  <div className="flex items-center justify-center h-9 bg-white">
                    <span className="text-[18px] font-bold text-gray-900 leading-none">
                      {event.date.split(' ')[1]}
                    </span>
                  </div>
                </div>
                <div>
                  <p className="text-[15px] font-semibold text-gray-900">
                    {event.dayOfWeek}, {event.date}
                  </p>
                  <p className="text-[13px] text-gray-500 flex items-center gap-1 mt-0.5">
                    <ClockIcon className="w-3.5 h-3.5" strokeWidth={2} />
                    {event.time} – {event.endTime}
                  </p>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-gray-100 mb-4" />

              {/* Location (tappable) */}
              <button onClick={() => setMapTapped(true)} className="w-full text-left mb-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{
                  backgroundColor: '#fee2e2'
                }}>
                    <MapPinIcon className="w-4 h-4" style={{
                    color: '#dc2626'
                  }} strokeWidth={2} />
                  </div>
                  <div>
                    <p className="text-[15px] font-semibold" style={{
                    color: '#2B7FE0'
                  }}>
                      {event.location}
                    </p>
                    <p className="text-[12px] text-gray-400">
                      {event.building} · Tap to open in Maps
                    </p>
                  </div>
                </div>
              </button>

              {/* Map snippet placeholder */}
              <button onClick={() => setMapTapped(true)} className="w-full h-36 rounded-2xl overflow-hidden mb-4 relative" style={{
              backgroundColor: '#e8f0e8'
            }}>
                {/* Fake map grid */}
                <div className="absolute inset-0 opacity-30">
                  {[0, 1, 2, 3, 4].map((i) => <div key={i} className="absolute w-full border-t border-gray-400" style={{
                  top: `${i * 25}%`
                }} />)}
                  {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="absolute h-full border-l border-gray-400" style={{
                  left: `${i * 20}%`
                }} />)}
                </div>
                {/* Road lines */}
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full h-5 bg-white opacity-60" />
                </div>
                <div className="absolute inset-0 flex justify-center">
                  <div className="h-full w-5 bg-white opacity-60" />
                </div>
                {/* Pin */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center shadow-lg" style={{
                    backgroundColor: event.color
                  }}>
                      <BuildingIcon className="w-5 h-5 text-white" strokeWidth={1.8} />
                    </div>
                    <div className="w-2 h-2 rounded-full mt-0.5" style={{
                    backgroundColor: event.color
                  }} />
                  </div>
                </div>
                {mapTapped && <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 rounded-2xl">
                    <span className="text-white text-[13px] font-semibold bg-black bg-opacity-50 px-3 py-1.5 rounded-full">
                      Opening Maps…
                    </span>
                  </div>}
              </button>

              {/* Organizer */}
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: event.organizerColor
              }}>
                  <span className="text-[11px] font-bold text-white">
                    {event.organizerInitials}
                  </span>
                </div>
                <div>
                  <p className="text-[12px] text-gray-400">Organized by</p>
                  <p className="text-[14px] font-semibold text-gray-900">
                    {event.organizer}
                  </p>
                </div>
              </div>
            </div>

            {/* Description */}
            {event.description && <div className="px-5 pb-5 border-t border-gray-100 pt-4">
                <p className="text-[14px] text-gray-600 leading-relaxed">
                  {event.description}
                </p>
              </div>}
          </div>

          {/* RSVP Section */}
          <div className="mx-4 mt-3 rounded-2xl px-4 py-4 shadow-sm" style={{
          backgroundColor: '#FFFFFF'
        }}>
            <p className="text-[12px] font-semibold text-gray-400 uppercase tracking-wide mb-3">
              Your RSVP
            </p>
            <div className="flex gap-2">
              {[{
              key: 'accept' as const,
              label: 'Accept',
              icon: <CheckIcon className="w-4 h-4" strokeWidth={2.5} />,
              active: '#5BAD72',
              activeBg: '#e8f4ea'
            }, {
              key: 'maybe' as const,
              label: 'Maybe',
              icon: <MinusIcon className="w-4 h-4" strokeWidth={2.5} />,
              active: '#f59e0b',
              activeBg: '#fef3c7'
            }, {
              key: 'decline' as const,
              label: 'Decline',
              icon: <XIcon className="w-4 h-4" strokeWidth={2.5} />,
              active: '#dc2626',
              activeBg: '#fee2e2'
            }].map((btn) => {
              const isSelected = rsvp === btn.key;
              return <button key={btn.key} onClick={() => setRsvp(btn.key)} className="flex-1 flex flex-col items-center gap-1 py-3 rounded-xl transition-all duration-150" style={{
                backgroundColor: isSelected ? btn.activeBg : '#f3f4f6',
                color: isSelected ? btn.active : '#6b7280',
                border: isSelected ? `1.5px solid ${btn.active}` : '1.5px solid transparent'
              }}>
                    {btn.icon}
                    <span className="text-[12px] font-semibold">
                      {btn.label}
                    </span>
                  </button>;
            })}
            </div>
          </div>

          {/* Add to Calendar */}
          <div className="mx-4 mt-3 mb-6">
            <button onClick={() => setAddedToCalendar(!addedToCalendar)} className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-[16px] transition-all duration-200 shadow-sm" style={{
            backgroundColor: addedToCalendar ? '#FFE4E8' : '#FB7185',
            color: addedToCalendar ? '#BE123C' : 'white',
            border: addedToCalendar ? '1.5px solid #FB7185' : 'none'
          }}>
              <PlusCircleIcon className="w-5 h-5" strokeWidth={2} />
              {addedToCalendar ? 'Added to Calendar ✓' : 'Add to Apple / Google Calendar'}
            </button>
          </div>
        </div>
      </div>
    </div>;
}