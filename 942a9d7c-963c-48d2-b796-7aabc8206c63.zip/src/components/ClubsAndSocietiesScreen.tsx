import React from 'react';
import { ChevronLeftIcon, ChevronRightIcon, UsersIcon } from 'lucide-react';
interface Club {
  id: string;
  name: string;
  role: string;
  avatarInitials: string;
  avatarColor: string;
}
const sampleClubs: Club[] = [{
  id: '1',
  name: 'Media Creative Society',
  role: 'Member',
  avatarInitials: 'MC',
  avatarColor: '#8B5CF6'
}, {
  id: '2',
  name: 'Architecture Society',
  role: 'Officer',
  avatarInitials: 'AS',
  avatarColor: '#F97316'
}, {
  id: '3',
  name: 'Design Collective',
  role: 'Member',
  avatarInitials: 'DC',
  avatarColor: '#06B6D4'
}, {
  id: '4',
  name: 'Urban Planning Club',
  role: 'Organiser',
  avatarInitials: 'UP',
  avatarColor: '#10B981'
}];
interface ClubsAndSocietiesScreenProps {
  onBack: () => void;
}
export function ClubsAndSocietiesScreen({
  onBack
}: ClubsAndSocietiesScreenProps) {
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F0F2F5'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1 flex-shrink-0" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Navigation Bar */}
        <div className="flex items-center justify-center relative px-4 py-3 flex-shrink-0" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <button onClick={onBack} className="absolute left-4 w-10 h-10 rounded-full border border-gray-300 bg-white flex items-center justify-center shadow-sm" aria-label="Go back">
            <ChevronLeftIcon className="w-5 h-5 text-gray-700" strokeWidth={2.5} />
          </button>
          <span className="text-[17px] font-semibold" style={{
          color: '#1A1D23'
        }}>
            Clubs & Societies
          </span>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none',
        backgroundColor: '#F0F2F5'
      }}>
          {/* Overlapping Club Avatars */}
          <div className="flex justify-center pt-8 pb-4">
            <div className="flex items-center">
              {sampleClubs.map((club, index) => <div key={club.id} className="w-[72px] h-[72px] rounded-full flex items-center justify-center border-[3px] border-white shadow-md flex-shrink-0" style={{
              backgroundColor: club.avatarColor,
              marginLeft: index === 0 ? '0px' : '-18px',
              zIndex: sampleClubs.length - index,
              position: 'relative'
            }}>
                  <span className="text-[18px] font-bold text-white select-none">
                    {club.avatarInitials}
                  </span>
                </div>)}
            </div>
          </div>

          {/* Large Title */}
          <div className="text-center pb-6 px-5">
            <h1 className="text-[34px] font-bold tracking-tight" style={{
            color: '#1A1D23'
          }}>
              Clubs & Societies
            </h1>
          </div>

          {/* Club List Card */}
          <div className="px-4 pb-3">
            <div className="rounded-2xl overflow-hidden" style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 4px rgba(0,0,0,0.07)'
          }}>
              {sampleClubs.map((club, index) => <div key={club.id}>
                  <button className="w-full flex items-center gap-4 px-4 py-4 hover:bg-gray-50 transition-colors text-left">
                    {/* Club Avatar */}
                    <div className="w-[52px] h-[52px] rounded-full flex items-center justify-center flex-shrink-0 shadow-sm" style={{
                  backgroundColor: club.avatarColor
                }}>
                      <span className="text-[16px] font-bold text-white select-none">
                        {club.avatarInitials}
                      </span>
                    </div>
                    {/* Name + Role */}
                    <div className="flex-1 min-w-0">
                      <p className="text-[17px] font-semibold leading-snug" style={{
                    color: '#1A1D23'
                  }}>
                        {club.name}
                      </p>
                      <p className="text-[14px] mt-0.5" style={{
                    color: '#9CA3AF'
                  }}>
                        {club.role}
                      </p>
                    </div>
                    <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                  color: '#C7C7CC'
                }} strokeWidth={2.5} />
                  </button>
                  {index < sampleClubs.length - 1 && <div className="border-t mx-4" style={{
                borderColor: '#F2F2F7'
              }} />}
                </div>)}
            </div>
          </div>

          {/* Helper Text */}
          <div className="px-5 pb-5">
            <p className="text-[14px] leading-relaxed" style={{
            color: '#9CA3AF'
          }}>
              See what club members can access and share.
            </p>
          </div>

          {/* Discover Card */}
          <div className="px-4 pb-6">
            <div className="rounded-2xl overflow-hidden" style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 4px rgba(0,0,0,0.07)'
          }}>
              <button className="w-full flex items-center gap-4 px-4 py-4 hover:bg-gray-50 transition-colors text-left">
                <div className="w-[52px] h-[52px] rounded-2xl flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: '#EDE9FE'
              }}>
                  <UsersIcon className="w-6 h-6" style={{
                  color: '#7C3AED'
                }} strokeWidth={2} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[17px] font-semibold leading-snug" style={{
                  color: '#1A1D23'
                }}>
                    Discover New Clubs
                  </p>
                  <p className="text-[13px] mt-0.5" style={{
                  color: '#9CA3AF'
                }}>
                    {sampleClubs.length} active memberships
                  </p>
                </div>
                <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                color: '#C7C7CC'
              }} strokeWidth={2.5} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>;
}