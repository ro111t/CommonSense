import React from 'react';
import { HouseIcon, LayersIcon, UserCircleIcon } from 'lucide-react';
export interface GlobalTabBarProps {
  activeTab: 'home' | 'mailboxes' | 'account';
  onNavigateHome: () => void;
  onNavigateMailboxes: () => void;
  onNavigateAccount: () => void;
}
export function GlobalTabBar({
  activeTab,
  onNavigateHome,
  onNavigateMailboxes,
  onNavigateAccount
}: GlobalTabBarProps) {
  const tabs: {
    id: 'home' | 'mailboxes' | 'account';
    label: string;
    icon: (active: boolean) => React.ReactNode;
    onPress: () => void;
  }[] = [{
    id: 'home',
    label: 'Home',
    icon: (active) => <HouseIcon className="w-6 h-6" strokeWidth={active ? 2.5 : 1.8} style={{
      color: active ? '#1A1D23' : '#9CA3AF'
    }} />,
    onPress: onNavigateHome
  }, {
    id: 'mailboxes',
    label: 'Portal',
    icon: (active) => <LayersIcon className="w-6 h-6" strokeWidth={active ? 2.5 : 1.8} style={{
      color: active ? '#1A1D23' : '#9CA3AF'
    }} />,
    onPress: onNavigateMailboxes
  }, {
    id: 'account',
    label: 'Profile',
    icon: (active) => <UserCircleIcon className="w-6 h-6" strokeWidth={active ? 2.5 : 1.8} style={{
      color: active ? '#1A1D23' : '#9CA3AF'
    }} />,
    onPress: onNavigateAccount
  }];
  return <div className="flex items-stretch border-t border-gray-100" style={{
    backgroundColor: '#FFFFFF',
    paddingBottom: '24px'
  }}>
      {tabs.map((tab) => {
      const isActive = activeTab === tab.id;
      return <button key={tab.id} onClick={tab.onPress} className="flex-1 flex flex-col items-center justify-center pt-3 pb-1 transition-opacity active:opacity-60" aria-label={tab.label} aria-pressed={isActive}>
            {tab.icon(isActive)}
            <span className="text-[11px] mt-1 font-semibold tracking-tight" style={{
          color: isActive ? '#1A1D23' : '#9CA3AF'
        }}>
              {tab.label}
            </span>
          </button>;
    })}
    </div>;
}