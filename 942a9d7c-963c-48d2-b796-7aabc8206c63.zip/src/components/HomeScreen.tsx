import React from 'react';
import { ChevronRightIcon } from 'lucide-react';
import { GlobalTabBar } from './GlobalTabBar';
import type { GlobalTabBarProps } from './GlobalTabBar';
type HomeScreenProps = Omit<GlobalTabBarProps, 'activeTab'> & {
  onNavigateToInboxes?: () => void;
};
export function HomeScreen({
  onNavigateHome,
  onNavigateMailboxes,
  onNavigateAccount
}: HomeScreenProps) {
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#FFFFFF'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-end justify-between px-5 pt-4 pb-4" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <h1 className="text-[34px] font-bold leading-tight tracking-tight" style={{
          color: '#1A1D23'
        }}>
            Home
          </h1>
          <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 mb-1" style={{
          backgroundColor: '#4F46E5'
        }}>
            <span className="text-[13px] font-bold text-white select-none">
              KF
            </span>
          </div>
        </div>

        {/* Scrollable Feed */}
        <div className="flex-1 overflow-y-auto" style={{
        backgroundColor: '#FFFFFF',
        scrollbarWidth: 'none'
      }}>
          {/* ── SECTION 1: Featured Clubs ── */}
          <div className="pt-5 pb-1">
            <p className="text-[20px] font-bold px-5 pb-3" style={{
            color: '#1A1D23'
          }}>
              Featured Clubs
            </p>
            <div className="flex gap-4 overflow-x-auto px-5 pb-3" style={{
            scrollbarWidth: 'none'
          }}>
              {/* Hero Card 1 */}
              <div className="flex-shrink-0 rounded-2xl flex flex-col justify-between p-5" style={{
              width: '310px',
              height: '180px',
              backgroundColor: '#4F46E5'
            }}>
                <div>
                  <span className="text-[11px] font-semibold text-white uppercase tracking-wide" style={{
                  opacity: 0.75
                }}>
                    Featured
                  </span>
                </div>
                <div>
                  <p className="text-[26px] font-bold text-white leading-tight">
                    Media Creative Society
                  </p>
                  <p className="text-[13px] text-white mt-0.5" style={{
                  opacity: 0.75
                }}>
                    Design · Media · Events
                  </p>
                  <p className="text-[12px] text-white mt-1" style={{
                  opacity: 0.6
                }}>
                    112 members
                  </p>
                </div>
              </div>

              {/* Hero Card 2 */}
              <div className="flex-shrink-0 rounded-2xl flex flex-col justify-between p-5" style={{
              width: '310px',
              height: '180px',
              backgroundColor: '#06B6D4'
            }}>
                <div>
                  <span className="text-[11px] font-semibold text-white uppercase tracking-wide" style={{
                  opacity: 0.75
                }}>
                    Active
                  </span>
                </div>
                <div>
                  <p className="text-[26px] font-bold text-white leading-tight">
                    Architecture Club
                  </p>
                  <p className="text-[13px] text-white mt-0.5" style={{
                  opacity: 0.75
                }}>
                    Design · Structure · Culture
                  </p>
                  <p className="text-[12px] text-white mt-1" style={{
                  opacity: 0.6
                }}>
                    67 members
                  </p>
                </div>
              </div>

              {/* Spacer for right padding */}
              <div className="flex-shrink-0 w-1" />
            </div>
          </div>

          {/* ── SECTION 2: Recommended for You ── */}
          <div className="pt-3 pb-1">
            <p className="text-[18px] font-bold px-5 pb-3" style={{
            color: '#1A1D23'
          }}>
              Recommended for You
            </p>
            <div className="flex gap-3 overflow-x-auto px-5 pb-3" style={{
            scrollbarWidth: 'none'
          }}>
              {/* Card: Typography Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#F06292'
              }}>
                  <span className="text-[28px] font-bold text-white">TC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Typography Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Design & Type
                </p>
              </div>

              {/* Card: Graphics Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#8B5CF6'
              }}>
                  <span className="text-[28px] font-bold text-white">GC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Graphics Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Visual Arts
                </p>
              </div>

              {/* Card: Football Flava */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#10B981'
              }}>
                  <span className="text-[28px] font-bold text-white">FF</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Football Flava
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Sports & Social
                </p>
              </div>

              {/* Card: Science Society */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#F97316'
              }}>
                  <span className="text-[28px] font-bold text-white">SC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Science Society
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Research & Labs
                </p>
              </div>

              <div className="flex-shrink-0 w-2" />
            </div>
          </div>

          {/* ── SECTION 3: Browse by Interest ── */}
          <div className="pt-3 pb-1">
            <p className="text-[18px] font-bold px-5 pb-3" style={{
            color: '#1A1D23'
          }}>
              Browse by Interest
            </p>
            <div className="flex gap-3 overflow-x-auto px-5 pb-3" style={{
            scrollbarWidth: 'none'
          }}>
              {/* Design */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#8B5CF6'
            }}>
                <span className="text-[14px] font-bold text-white">Design</span>
              </div>

              {/* Engineering */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#06B6D4'
            }}>
                <span className="text-[14px] font-bold text-white">
                  Engineering
                </span>
              </div>

              {/* Sports */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#10B981'
            }}>
                <span className="text-[14px] font-bold text-white">Sports</span>
              </div>

              {/* Arts */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#F97316'
            }}>
                <span className="text-[14px] font-bold text-white">Arts</span>
              </div>

              {/* Media */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#4F46E5'
            }}>
                <span className="text-[14px] font-bold text-white">Media</span>
              </div>

              {/* Science */}
              <div className="flex-shrink-0 rounded-2xl flex items-center justify-center" style={{
              width: '120px',
              height: '80px',
              backgroundColor: '#FB7185'
            }}>
                <span className="text-[14px] font-bold text-white">
                  Science
                </span>
              </div>

              <div className="flex-shrink-0 w-2" />
            </div>
          </div>

          {/* ── SECTION 4: New & Active ── */}
          <div className="pt-3 pb-1">
            <div className="flex items-center justify-between px-5 pb-3">
              <p className="text-[18px] font-bold" style={{
              color: '#1A1D23'
            }}>
                New & Active
              </p>
              <button className="flex items-center gap-0.5" aria-label="See all new and active clubs">
                <span className="text-[14px] font-medium" style={{
                color: '#9CA3AF'
              }}>
                  See All
                </span>
                <ChevronRightIcon className="w-4 h-4" style={{
                color: '#9CA3AF'
              }} strokeWidth={2} />
              </button>
            </div>
            <div className="flex gap-3 overflow-x-auto px-5 pb-3" style={{
            scrollbarWidth: 'none'
          }}>
              {/* Card: Drama Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#FB7185'
              }}>
                  <span className="text-[28px] font-bold text-white">DC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Drama Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Theatre & Performance
                </p>
              </div>

              {/* Card: Photography */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#F59E0B'
              }}>
                  <span className="text-[28px] font-bold text-white">PC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Photography
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Visual Storytelling
                </p>
              </div>

              {/* Card: Robotics Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#06B6D4'
              }}>
                  <span className="text-[28px] font-bold text-white">RC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Robotics Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Engineering & AI
                </p>
              </div>

              {/* Card: Entrepreneurship */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#8B5CF6'
              }}>
                  <span className="text-[28px] font-bold text-white">EC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Entrepreneurship
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Business & Startups
                </p>
              </div>

              <div className="flex-shrink-0 w-2" />
            </div>
          </div>

          {/* ── SECTION 5: Trending This Week ── */}
          <div className="pt-3 pb-6">
            <div className="flex items-center justify-between px-5 pb-3">
              <p className="text-[18px] font-bold" style={{
              color: '#1A1D23'
            }}>
                Trending This Week
              </p>
              <button className="flex items-center gap-0.5" aria-label="See all trending clubs">
                <span className="text-[14px] font-medium" style={{
                color: '#9CA3AF'
              }}>
                  See All
                </span>
                <ChevronRightIcon className="w-4 h-4" style={{
                color: '#9CA3AF'
              }} strokeWidth={2} />
              </button>
            </div>
            <div className="flex gap-3 overflow-x-auto px-5 pb-3" style={{
            scrollbarWidth: 'none'
          }}>
              {/* Card: Debate Society */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#10B981'
              }}>
                  <span className="text-[28px] font-bold text-white">DS</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Debate Society
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Public Speaking
                </p>
              </div>

              {/* Card: Astronomy Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#4F46E5'
              }}>
                  <span className="text-[28px] font-bold text-white">AC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Astronomy Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Space & Science
                </p>
              </div>

              {/* Card: Chess Club */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#F97316'
              }}>
                  <span className="text-[28px] font-bold text-white">CC</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Chess Club
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Strategy & Games
                </p>
              </div>

              {/* Card: Music Society */}
              <div className="flex-shrink-0" style={{
              width: '148px'
            }}>
                <div className="w-full rounded-2xl flex items-center justify-center" style={{
                height: '148px',
                backgroundColor: '#FB7185'
              }}>
                  <span className="text-[28px] font-bold text-white">MS</span>
                </div>
                <p className="text-[13px] font-semibold mt-2 truncate" style={{
                color: '#1A1D23'
              }}>
                  Music Society
                </p>
                <p className="text-[12px] truncate" style={{
                color: '#9CA3AF'
              }}>
                  Performance & Theory
                </p>
              </div>

              <div className="flex-shrink-0 w-2" />
            </div>
          </div>
        </div>

        {/* Global Tab Bar */}
        <GlobalTabBar activeTab="home" onNavigateHome={onNavigateHome} onNavigateMailboxes={onNavigateMailboxes} onNavigateAccount={onNavigateAccount} />
      </div>
    </div>;
}