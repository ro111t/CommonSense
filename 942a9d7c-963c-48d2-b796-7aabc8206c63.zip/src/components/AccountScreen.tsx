import React, { useState } from 'react';
import { PencilIcon, ShareIcon, MapPinIcon, UsersIcon, GlobeIcon, LinkedinIcon, BookOpenIcon, BellIcon, ShieldIcon, LogOutIcon, ChevronRightIcon, UserPlusIcon, MessageCircleIcon, HeartIcon, ExternalLinkIcon } from 'lucide-react';
import { GlobalTabBar } from './GlobalTabBar';
import type { GlobalTabBarProps } from './GlobalTabBar';
type AccountScreenProps = Omit<GlobalTabBarProps, 'activeTab'> & {
  onNavigateClubs?: () => void;
};
export function AccountScreen({
  onNavigateHome,
  onNavigateMailboxes,
  onNavigateAccount,
  onNavigateClubs
}: AccountScreenProps) {
  const [following, setFollowing] = useState(false);
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F0F2F5'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1 flex-shrink-0" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none',
        backgroundColor: '#F0F2F5'
      }}>
          {/* ── iOS SETTINGS-STYLE PROFILE HEADER ── */}
          {/* Large title */}
          <div className="px-5 pt-4 pb-3">
            
          </div>

          {/* iOS Settings-style identity card */}
          <div className="px-4 pb-4">
            <div className="rounded-2xl overflow-hidden" style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 4px rgba(0,0,0,0.07)'
          }}>
              {/* Row 1: User identity */}
              <button className="w-full flex items-center gap-4 px-4 py-4 hover:bg-gray-50 transition-colors text-left">
                {/* Avatar */}
                <div className="w-[62px] h-[62px] rounded-full flex items-center justify-center flex-shrink-0 shadow-sm" style={{
                backgroundColor: '#4F46E5'
              }}>
                  <span className="text-[22px] font-bold text-white select-none">
                    KF
                  </span>
                </div>
                {/* Name + subtitle */}
                <div className="flex-1 min-w-0">
                  <p className="text-[20px] font-bold leading-snug" style={{
                  color: '#1A1D23'
                }}>
                    Karl Fog
                  </p>
                  <p className="text-[14px] mt-0.5 leading-snug" style={{
                  color: '#9CA3AF'
                }}>
                    Architecture · Cape Town · 2nd Year
                  </p>
                </div>
                <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                color: '#C7C7CC'
              }} strokeWidth={2.5} />
              </button>

              {/* Divider */}
              <div className="border-t mx-4" style={{
              borderColor: '#F2F2F7'
            }} />

              {/* Row 2: Clubs / connections */}
              <button className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-gray-50 transition-colors text-left" onClick={onNavigateClubs}>
                {/* Overlapping avatars */}
                <div className="flex items-center flex-shrink-0" style={{
                width: '62px'
              }}>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center border-2 border-white z-30" style={{
                  backgroundColor: '#8B5CF6',
                  marginLeft: '0px'
                }}>
                    <span className="text-[9px] font-bold text-white">AC</span>
                  </div>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center border-2 border-white z-20" style={{
                  backgroundColor: '#F97316',
                  marginLeft: '-8px'
                }}>
                    <span className="text-[9px] font-bold text-white">JL</span>
                  </div>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center border-2 border-white z-10" style={{
                  backgroundColor: '#06B6D4',
                  marginLeft: '-8px'
                }}>
                    <span className="text-[9px] font-bold text-white">SR</span>
                  </div>
                </div>
                {/* Label */}
                <div className="flex-1 min-w-0">
                  <p className="text-[17px] font-medium" style={{
                  color: '#1A1D23'
                }}>
                    Clubs & Societies
                  </p>
                </div>
                <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                color: '#C7C7CC'
              }} strokeWidth={2.5} />
              </button>
            </div>
          </div>

          {/* ── BENTO BOX PROJECTS ── */}
          <div className="px-4 pb-4">
            {/* Section header */}
            <div className="flex items-center justify-between mb-3">
              <p className="text-[13px] font-bold uppercase tracking-widest" style={{
              color: '#1A1D23'
            }}>
                Projects
              </p>
            </div>

            {/* BENTO GRID — 2-column asymmetric layout */}
            <div className="flex gap-2">
              {/* LEFT COLUMN */}
              <div className="flex flex-col gap-2 flex-1">
                {/* Tall featured card */}
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-4" style={{
                height: '180px',
                backgroundColor: '#1e1b4b'
              }}>
                  <div className="absolute bottom-0 right-0 w-28 h-28 rounded-full opacity-20" style={{
                  border: '18px solid #7C3AED',
                  transform: 'translate(30%, 30%)'
                }} />
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wide" style={{
                    backgroundColor: 'rgba(124,58,237,0.35)',
                    color: '#C4B5FD'
                  }}>
                      Featured
                    </span>
                    <span className="text-[10px]" style={{
                    color: 'rgba(255,255,255,0.4)'
                  }}>
                      2024
                    </span>
                  </div>
                  <div>
                    <p className="text-[16px] font-bold text-white leading-tight">
                      Parametric Pavilion
                    </p>
                    <p className="text-[11px] mt-0.5" style={{
                    color: 'rgba(255,255,255,0.5)'
                  }}>
                      Studio III · Rhino + Grasshopper
                    </p>
                  </div>
                </div>

                {/* Medium card */}
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3.5" style={{
                height: '120px',
                backgroundColor: '#0d3d3d'
              }}>
                  <div className="absolute bottom-0 right-0 w-20 h-20 rounded-full opacity-20" style={{
                  border: '14px solid #0891B2',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="self-start px-2 py-0.5 rounded-full text-[10px] font-bold uppercase" style={{
                  backgroundColor: 'rgba(8,145,178,0.3)',
                  color: '#67E8F9'
                }}>
                    Thesis
                  </span>
                  <div>
                    <p className="text-[13px] font-bold text-white leading-snug">
                      Urban Micro-Housing
                    </p>
                    <p className="text-[11px] mt-0.5" style={{
                    color: 'rgba(255,255,255,0.45)'
                  }}>
                      Cape Town · 2025
                    </p>
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN */}
              <div className="flex flex-col gap-2 flex-1">
                {/* Medium card */}
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3.5" style={{
                height: '120px',
                backgroundColor: '#1a2e1a'
              }}>
                  <div className="absolute bottom-0 right-0 w-16 h-16 rounded-full opacity-25" style={{
                  border: '12px solid #059669',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="self-start px-2 py-0.5 rounded-full text-[10px] font-bold uppercase" style={{
                  backgroundColor: 'rgba(5,150,105,0.3)',
                  color: '#6EE7B7'
                }}>
                    Studio II
                  </span>
                  <div>
                    <p className="text-[13px] font-bold text-white leading-snug">
                      Sustainable Shelter
                    </p>
                    <p className="text-[11px] mt-0.5" style={{
                    color: 'rgba(255,255,255,0.45)'
                  }}>
                      2023
                    </p>
                  </div>
                </div>

                {/* Small card 1 */}
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3" style={{
                height: '86px',
                backgroundColor: '#0f1f3d'
              }}>
                  <div className="absolute bottom-0 right-0 w-14 h-14 rounded-full opacity-20" style={{
                  border: '10px solid #3B82F6',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="text-[9px] font-bold uppercase" style={{
                  color: 'rgba(147,197,253,0.7)'
                }}>
                    Research
                  </span>
                  <p className="text-[12px] font-bold text-white leading-snug">
                    Structural Study
                  </p>
                </div>

                {/* Small card 2 */}
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3" style={{
                height: '86px',
                backgroundColor: '#2d1040'
              }}>
                  <div className="absolute bottom-0 right-0 w-14 h-14 rounded-full opacity-20" style={{
                  border: '10px solid #8B5CF6',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="text-[9px] font-bold uppercase" style={{
                  color: 'rgba(196,181,253,0.7)'
                }}>
                    Urban
                  </span>
                  <p className="text-[12px] font-bold text-white leading-snug">
                    Waterfront Plan
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ── COLLABORATORS ── */}

          {/* ── CLUBS ── */}

          {/* ── SKILLS ── */}

          {/* ── LINKS & ACCOUNT ── */}
          <div className="px-4 pb-3">
            <div className="rounded-2xl overflow-hidden" style={{
            backgroundColor: '#FFFFFF',
            boxShadow: '0 1px 4px rgba(0,0,0,0.05)'
          }}>
              <button className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 transition-colors text-left">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: '#EFF6FF'
              }}>
                  <LinkedinIcon className="w-4 h-4" style={{
                  color: '#2563EB'
                }} strokeWidth={2} />
                </div>
                <span className="flex-1 text-[14px] font-medium" style={{
                color: '#1A1D23'
              }}>
                  LinkedIn
                </span>
                <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                color: '#C7C7CC'
              }} strokeWidth={2.5} />
              </button>
              <div className="border-t mx-4" style={{
              borderColor: '#F2F2F7'
            }} />
              <button className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 transition-colors text-left">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: '#F3F4F6'
              }}>
                  <GlobeIcon className="w-4 h-4" style={{
                  color: '#6B7280'
                }} strokeWidth={2} />
                </div>
                <span className="flex-1 text-[14px] font-medium" style={{
                color: '#1A1D23'
              }}>
                  karlf.design
                </span>
                <ChevronRightIcon className="w-4 h-4 flex-shrink-0" style={{
                color: '#C7C7CC'
              }} strokeWidth={2.5} />
              </button>
              <div className="border-t mx-4" style={{
              borderColor: '#F2F2F7'
            }} />

              <div className="border-t mx-4" style={{
              borderColor: '#F2F2F7'
            }} />
              <button className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 transition-colors text-left">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: '#FEF2F2'
              }}>
                  <LogOutIcon className="w-4 h-4" style={{
                  color: '#DC2626'
                }} strokeWidth={2} />
                </div>
                <span className="flex-1 text-[14px] font-medium" style={{
                color: '#DC2626'
              }}>
                  Sign Out
                </span>
              </button>
            </div>
          </div>

          <div className="h-4" />
        </div>

        {/* Global Tab Bar */}
        <GlobalTabBar activeTab="account" onNavigateHome={onNavigateHome} onNavigateMailboxes={onNavigateMailboxes} onNavigateAccount={onNavigateAccount} />
      </div>
    </div>;
}