import React, { useState } from 'react';
import { ChevronLeftIcon, UserIcon, FileTextIcon, ImageIcon, PlayCircleIcon, DownloadIcon, CalendarIcon, CheckCircleIcon, ClockIcon, LightbulbIcon } from 'lucide-react';
export interface ProjectAttachment {
  name: string;
  type: 'pdf' | 'images' | 'video' | 'doc';
  size: string;
}
export interface Project {
  id: string;
  name: string;
  leadMember: string;
  leadAvatarInitials: string;
  leadAvatarColor: string;
  status: 'Completed' | 'In Progress' | 'Planning';
  date: string;
  tagline: string;
  description: string;
  highlights: string[];
  attachments: ProjectAttachment[];
}
interface ProjectDetailScreenProps {
  project: Project;
  onBack: () => void;
}
const statusConfig = {
  Completed: {
    bg: '#e8f4ea',
    text: '#3a8c50',
    icon: <CheckCircleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  'In Progress': {
    bg: '#e8f0fb',
    text: '#2B7FE0',
    icon: <ClockIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  Planning: {
    bg: '#fef3c7',
    text: '#b45309',
    icon: <LightbulbIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  }
};
const attachmentConfig = {
  pdf: {
    bg: '#fee2e2',
    icon: <FileTextIcon className="w-5 h-5" strokeWidth={2} />,
    color: '#dc2626',
    label: 'PDF'
  },
  images: {
    bg: '#e0f2fe',
    icon: <ImageIcon className="w-5 h-5" strokeWidth={2} />,
    color: '#0284c7',
    label: 'Photos'
  },
  video: {
    bg: '#f3e8ff',
    icon: <PlayCircleIcon className="w-5 h-5" strokeWidth={2} />,
    color: '#7c3aed',
    label: 'Video'
  },
  doc: {
    bg: '#e8f4ea',
    icon: <FileTextIcon className="w-5 h-5" strokeWidth={2} />,
    color: '#3a8c50',
    label: 'Doc'
  }
};
// Placeholder image blocks using a simple grid of colored sections
const ImagePlaceholder = ({
  label,
  color



}: {label: string;color: string;}) => <div className="w-full h-44 rounded-2xl flex flex-col items-center justify-center gap-2" style={{
  backgroundColor: color + '18',
  border: `1.5px solid ${color}30`
}}>
    <ImageIcon className="w-8 h-8" style={{
    color
  }} strokeWidth={1.5} />
    <span className="text-[13px] font-medium" style={{
    color
  }}>
      {label}
    </span>
  </div>;
export function ProjectDetailScreen({
  project,
  onBack
}: ProjectDetailScreenProps) {
  const [expandedAttachment, setExpandedAttachment] = useState<string | null>(null);
  const status = statusConfig[project.status];
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Nav Bar */}
        <div className="flex items-center px-4 py-2 border-b" style={{
        backgroundColor: '#F0F2F5',
        borderColor: '#E5E7EB'
      }}>
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#06B6D4'
        }} aria-label="Back to Projects">
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Projects</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none'
      }}>
          {/* Hero Header */}
          <div className="px-5 pt-5 pb-5" style={{
          backgroundColor: '#FFFFFF'
        }}>
            {/* Status badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-3" style={{
            backgroundColor: status.bg,
            color: status.text
          }}>
              {status.icon}
              <span className="text-[12px] font-semibold">
                {project.status}
              </span>
            </div>

            {/* Project name */}
            <h1 className="text-[26px] font-bold text-gray-900 leading-tight mb-1">
              {project.name}
            </h1>
            <p className="text-[14px] text-gray-400 italic mb-4">
              {project.tagline}
            </p>

            {/* Lead member row */}
            <div className="flex items-center gap-3 p-3 rounded-2xl" style={{
            backgroundColor: '#f8f8f8'
          }}>
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{
              backgroundColor: project.leadAvatarColor
            }}>
                <span className="text-[14px] font-bold text-white">
                  {project.leadAvatarInitials}
                </span>
              </div>
              <div>
                <p className="text-[12px] text-gray-400 font-medium">
                  Project Lead
                </p>
                <p className="text-[15px] font-semibold text-gray-900">
                  {project.leadMember}
                </p>
              </div>
              <div className="ml-auto flex items-center gap-1 text-gray-400">
                <CalendarIcon className="w-3.5 h-3.5" strokeWidth={2} />
                <span className="text-[12px]">{project.date}</span>
              </div>
            </div>
          </div>

          <div className="px-4 py-4 space-y-4">
            {/* Description */}
            <div className="rounded-2xl px-4 py-4 shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <p className="text-[12px] font-semibold text-gray-400 uppercase tracking-wide mb-2">
                About This Project
              </p>
              <p className="text-[15px] text-gray-700 leading-relaxed">
                {project.description}
              </p>
            </div>

            {/* Image placeholder 1 */}
            <ImagePlaceholder label="Event Photography" color="#5BAD72" />

            {/* Highlights */}
            <div className="rounded-2xl px-4 py-4 shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <p className="text-[12px] font-semibold text-gray-400 uppercase tracking-wide mb-3">
                Key Highlights
              </p>
              <div className="space-y-2">
                {project.highlights.map((h, i) => <div key={i} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{
                  backgroundColor: '#5BAD72'
                }} />
                    <p className="text-[14px] text-gray-700">{h}</p>
                  </div>)}
              </div>
            </div>

            {/* Image placeholder 2 */}
            <ImagePlaceholder label="Behind the Scenes" color="#7C6FCD" />

            {/* Attachments */}
            <div className="rounded-2xl overflow-hidden shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <div className="px-4 pt-4 pb-2">
                <p className="text-[12px] font-semibold text-gray-400 uppercase tracking-wide">
                  Attachments
                </p>
              </div>
              {project.attachments.map((att, index) => {
              const config = attachmentConfig[att.type];
              return <div key={att.name}>
                    {index > 0 && <div className="border-t border-gray-100 ml-16" />}
                    <button onClick={() => setExpandedAttachment(expandedAttachment === att.name ? null : att.name)} className="w-full flex items-center gap-3 px-4 py-3.5 active:bg-gray-50 transition-colors">
                      {/* File icon */}
                      <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{
                    backgroundColor: config.bg
                  }}>
                        <span style={{
                      color: config.color
                    }}>
                          {config.icon}
                        </span>
                      </div>
                      {/* File info */}
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-[15px] font-semibold text-gray-900 truncate">
                          {att.name}
                        </p>
                        <p className="text-[12px] text-gray-400">
                          {config.label} · {att.size}
                        </p>
                      </div>
                      {/* Download icon */}
                      <DownloadIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2} />
                    </button>
                  </div>;
            })}
            </div>

            {/* Bottom padding */}
            <div className="h-4" />
          </div>
        </div>
      </div>
    </div>;
}