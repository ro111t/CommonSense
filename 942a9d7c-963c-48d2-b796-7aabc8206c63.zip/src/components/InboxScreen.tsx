import React, { useState } from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from 'lucide-react';
export interface Conversation {
  id: string;
  name: string;
  date: string;
  preview: string;
  unread: boolean;
  messages: Message[];
}
export interface Message {
  id: string;
  text: string;
  sender: 'me' | 'them';
  time: string;
}
export const sampleConversations: Conversation[] = [{
  id: '1',
  name: 'Denise',
  date: '26/12/2025',
  preview: 'The design must be a combination of both architectural styles.',
  unread: true,
  messages: [{
    id: '1',
    text: 'Hey, have you started on the structural analysis?',
    sender: 'them',
    time: '10:00 AM'
  }, {
    id: '2',
    text: 'Yes, I was looking at the load distribution diagrams.',
    sender: 'me',
    time: '10:05 AM'
  }, {
    id: '3',
    text: 'The design must be a combination of both architectural styles.',
    sender: 'them',
    time: '10:08 AM'
  }, {
    id: '4',
    text: 'Agreed. I think we should merge the cantilever approach with the truss system.',
    sender: 'me',
    time: '10:12 AM'
  }, {
    id: '5',
    text: 'Exactly. Let me send over the revised sketches by tomorrow.',
    sender: 'them',
    time: '10:15 AM'
  }]
}, {
  id: '2',
  name: 'Josh',
  date: '26/12/2025',
  preview: 'The design must be a combination of both architectural styles.',
  unread: false,
  messages: [{
    id: '1',
    text: 'Did you complete the differential equations for the beam problem?',
    sender: 'them',
    time: '9:00 AM'
  }, {
    id: '2',
    text: 'Working on it now. The boundary conditions are tricky.',
    sender: 'me',
    time: '9:10 AM'
  }, {
    id: '3',
    text: 'The design must be a combination of both architectural styles.',
    sender: 'them',
    time: '9:20 AM'
  }]
}, {
  id: '3',
  name: 'Rohit',
  date: '26/12/2025',
  preview: 'The design must be a combination of both architectural styles.',
  unread: false,
  messages: [{
    id: '1',
    text: 'Can you review my free body diagram for the bridge section?',
    sender: 'them',
    time: '8:30 AM'
  }, {
    id: '2',
    text: 'Sure, send it over.',
    sender: 'me',
    time: '8:35 AM'
  }, {
    id: '3',
    text: 'The design must be a combination of both architectural styles.',
    sender: 'them',
    time: '8:40 AM'
  }, {
    id: '4',
    text: 'I see what you mean. The reaction forces need to be recalculated.',
    sender: 'me',
    time: '8:45 AM'
  }]
}, {
  id: '4',
  name: 'Joel',
  date: '26/12/2025',
  preview: 'The design must be a combination of both architectural styles.',
  unread: false,
  messages: [{
    id: '1',
    text: 'The stiffness matrix approach should simplify the analysis significantly.',
    sender: 'them',
    time: '7:00 AM'
  }, {
    id: '2',
    text: 'The design must be a combination of both architectural styles.',
    sender: 'them',
    time: '7:05 AM'
  }, {
    id: '3',
    text: 'I agree. Let me run the finite element model tonight.',
    sender: 'me',
    time: '7:10 AM'
  }]
}, {
  id: '5',
  name: 'Leo',
  date: '25/12/2025',
  preview: 'Please review the updated beam calculations before next session.',
  unread: false,
  messages: [{
    id: '1',
    text: 'I updated the load analysis spreadsheet with the new values.',
    sender: 'them',
    time: 'Yesterday'
  }, {
    id: '2',
    text: 'Please review the updated beam calculations before next session.',
    sender: 'them',
    time: 'Yesterday'
  }, {
    id: '3',
    text: 'Got it, will review tonight.',
    sender: 'me',
    time: 'Yesterday'
  }]
}, {
  id: '6',
  name: 'Eli',
  date: '24/12/2025',
  preview: 'Your submission has been reviewed. See comments attached.',
  unread: false,
  messages: [{
    id: '1',
    text: 'Your submission has been reviewed. See comments attached.',
    sender: 'them',
    time: 'Dec 24'
  }, {
    id: '2',
    text: 'Thank you! I will address the feedback on the I-beam cross section.',
    sender: 'me',
    time: 'Dec 24'
  }]
}];
type NavTab = 'Inbox' | 'Sent' | 'Archive';
interface InboxScreenProps {
  onBack: () => void;
  onViewConversation: (conversation: Conversation) => void;
}
export function InboxScreen({
  onBack,
  onViewConversation
}: InboxScreenProps) {
  const [activeTab, setActiveTab] = useState<NavTab>('Inbox');
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#FFFFFF'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Back Nav */}
        <div className="flex items-center px-4 py-2" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#4b5563'
        }} aria-label="Go back">
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Back</span>
          </button>
        </div>

        {/* Title Section */}
        <div className="px-5 pt-3 pb-5" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <h1 className="text-[34px] font-bold leading-tight tracking-tight" style={{
          color: '#1A1D23'
        }}>
            Inbox
          </h1>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto" style={{
        backgroundColor: '#FFFFFF',
        scrollbarWidth: 'none'
      }}>
          {sampleConversations.map((conv) => <button key={conv.id} onClick={() => onViewConversation(conv)} className="w-full flex items-center gap-3 px-5 py-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0 text-left">
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[16px] leading-snug" style={{
                fontWeight: conv.unread ? 700 : 600,
                color: '#1A1D23'
              }}>
                    {conv.name}
                  </span>
                  <span className="text-[13px] ml-3 flex-shrink-0" style={{
                color: '#9CA3AF'
              }}>
                    {conv.date}
                  </span>
                </div>
                <p className="text-[13px] leading-snug line-clamp-2" style={{
              color: '#9CA3AF'
            }}>
                  {conv.preview}
                </p>
              </div>
              <ChevronRightIcon className="w-4 h-4 flex-shrink-0 ml-2" style={{
            color: '#9CA3AF'
          }} strokeWidth={2.5} />
            </button>)}
        </div>

        {/* Bottom Nav Bar */}
        <div className="flex items-center justify-between px-5 py-3 border-t border-gray-100" style={{
        paddingBottom: '24px',
        backgroundColor: '#FFFFFF'
      }}>
          {(['Inbox', 'Sent', 'Archive'] as NavTab[]).map((tab) => {
          const isActive = activeTab === tab;
          return <button key={tab} onClick={() => setActiveTab(tab)} className="flex-1 mx-1.5 py-2.5 rounded-full text-[14px] font-semibold transition-colors" style={{
            backgroundColor: isActive ? '#D1D5DB' : '#F3F4F6',
            color: isActive ? '#1A1D23' : '#6B7280'
          }} aria-pressed={isActive}>
                {tab}
              </button>;
        })}
        </div>
      </div>
    </div>;
}