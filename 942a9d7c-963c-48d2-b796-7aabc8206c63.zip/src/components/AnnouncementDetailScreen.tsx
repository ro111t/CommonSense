import React, { useState } from 'react';
import { ChevronLeftIcon, CheckCircleIcon, EyeIcon, CalendarIcon, AlertCircleIcon, InfoIcon, AlertTriangleIcon, ChevronDownIcon, ChevronRightIcon } from 'lucide-react';
export interface ReadReceipt {
  name: string;
  initials: string;
  color: string;
  readAt: string;
}
export interface Announcement {
  id: string;
  title: string;
  sender: string;
  senderInitials: string;
  senderColor: string;
  date: string;
  urgency: 'urgent' | 'important' | 'info';
  body: string;
  type: 'attendance' | 'info';
  totalMembers: number;
  readReceipts: ReadReceipt[];
}
interface AnnouncementDetailScreenProps {
  announcement: Announcement;
  isAdmin?: boolean;
  onBack: () => void;
}
const urgencyConfig = {
  urgent: {
    label: 'Urgent',
    bg: '#fee2e2',
    text: '#dc2626',
    border: '#dc2626',
    dot: '#dc2626',
    icon: <AlertCircleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  important: {
    label: 'Important',
    bg: '#fef3c7',
    text: '#b45309',
    border: '#f59e0b',
    dot: '#f59e0b',
    icon: <AlertTriangleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  info: {
    label: 'Info',
    bg: '#e8f0fb',
    text: '#2B7FE0',
    border: '#2B7FE0',
    dot: '#2B7FE0',
    icon: <InfoIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  }
};
export function AnnouncementDetailScreen({
  announcement,
  isAdmin = true,
  onBack
}: AnnouncementDetailScreenProps) {
  const [confirmed, setConfirmed] = useState(false);
  const [receiptsExpanded, setReceiptsExpanded] = useState(false);
  const urgency = urgencyConfig[announcement.urgency];
  const readCount = announcement.readReceipts.length;
  const readPercent = Math.round(readCount / announcement.totalMembers * 100);
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Nav Bar */}
        <div className="flex items-center px-4 py-2 border-b" style={{
        backgroundColor: '#F0F2F5',
        borderColor: '#E5E7EB'
      }}>
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#F97316'
        }} aria-label="Back to Announcements">
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Announcements</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none'
      }}>
          {/* Header Card */}
          <div className="px-5 pt-5 pb-5 border-l-4" style={{
          borderLeftColor: urgency.border,
          backgroundColor: '#FFFFFF'
        }}>
            {/* Urgency badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-3" style={{
            backgroundColor: urgency.bg,
            color: urgency.text
          }}>
              {urgency.icon}
              <span className="text-[12px] font-bold uppercase tracking-wide">
                {urgency.label}
              </span>
            </div>

            {/* Title */}
            <h1 className="text-[22px] font-bold text-gray-900 leading-snug mb-4">
              {announcement.title}
            </h1>

            {/* Sender row */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{
              backgroundColor: announcement.senderColor
            }}>
                <span className="text-[13px] font-bold text-white">
                  {announcement.senderInitials}
                </span>
              </div>
              <div className="flex-1">
                <p className="text-[15px] font-semibold text-gray-900">
                  {announcement.sender}
                </p>
                <div className="flex items-center gap-1 text-gray-400">
                  <CalendarIcon className="w-3 h-3" strokeWidth={2} />
                  <span className="text-[12px]">{announcement.date}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="px-4 py-4 space-y-3">
            {/* Body */}
            <div className="rounded-2xl px-4 py-4 shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <p className="text-[15px] text-gray-800 leading-relaxed">
                {announcement.body}
              </p>
            </div>

            {/* CTA Button */}
            {announcement.type === 'attendance' ? <button onClick={() => setConfirmed(!confirmed)} className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-[16px] transition-all duration-200 shadow-sm" style={{
            backgroundColor: confirmed ? '#e8f4ea' : '#5BAD72',
            color: confirmed ? '#3a8c50' : 'white',
            border: confirmed ? '1.5px solid #5BAD72' : 'none'
          }}>
                <CheckCircleIcon className="w-5 h-5" strokeWidth={2.5} />
                {confirmed ? 'Attendance Confirmed ✓' : 'Confirm Attendance'}
              </button> : <button onClick={() => setConfirmed(!confirmed)} className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-[16px] transition-all duration-200 shadow-sm" style={{
            backgroundColor: confirmed ? '#e8f0fb' : '#7C6FCD',
            color: confirmed ? '#5a4fa0' : 'white',
            border: confirmed ? '1.5px solid #7C6FCD' : 'none'
          }}>
                <EyeIcon className="w-5 h-5" strokeWidth={2.5} />
                {confirmed ? 'Marked as Read ✓' : 'Mark as Read'}
              </button>}

            {/* Admin Read Receipts */}
            {isAdmin && <div className="rounded-2xl overflow-hidden shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
                {/* Header row */}
                <button onClick={() => setReceiptsExpanded(!receiptsExpanded)} className="w-full flex items-center justify-between px-4 py-4">
                  <div className="flex items-center gap-2">
                    <EyeIcon className="w-4 h-4 text-gray-500" strokeWidth={2} />
                    <span className="text-[14px] font-semibold text-gray-700">
                      Read Receipts
                    </span>
                    <span className="text-[12px] font-bold px-2 py-0.5 rounded-full" style={{
                  backgroundColor: '#E6FAF3',
                  color: '#0D7A52'
                }}>
                      {readCount}/{announcement.totalMembers}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {/* Progress bar */}
                    <div className="w-16 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                      <div className="h-full rounded-full transition-all" style={{
                    width: `${readPercent}%`,
                    backgroundColor: '#5BAD72'
                  }} />
                    </div>
                    <span className="text-[12px] text-gray-400">
                      {readPercent}%
                    </span>
                    <ChevronDownIcon className="w-4 h-4 text-gray-400 transition-transform duration-200" strokeWidth={2.5} style={{
                  transform: receiptsExpanded ? 'rotate(180deg)' : 'rotate(0deg)'
                }} />
                  </div>
                </button>

                {/* Receipt list */}
                {receiptsExpanded && <div className="border-t border-gray-100">
                    {announcement.readReceipts.map((r, i) => <div key={i} className="flex items-center gap-3 px-4 py-3 border-b border-gray-50 last:border-0">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{
                  backgroundColor: r.color
                }}>
                          <span className="text-[11px] font-bold text-white">
                            {r.initials}
                          </span>
                        </div>
                        <span className="flex-1 text-[14px] font-medium text-gray-800">
                          {r.name}
                        </span>
                        <span className="text-[12px] text-gray-400">
                          {r.readAt}
                        </span>
                        <CheckCircleIcon className="w-4 h-4 flex-shrink-0" style={{
                  color: '#5BAD72'
                }} strokeWidth={2.5} />
                      </div>)}
                    {/* Unread count hint */}
                    <div className="px-4 py-3 bg-gray-50">
                      <p className="text-[12px] text-gray-400 text-center">
                        {announcement.totalMembers - readCount} member
                        {announcement.totalMembers - readCount !== 1 ? 's' : ''}{' '}
                        haven't seen this yet
                      </p>
                    </div>
                  </div>}
              </div>}

            <div className="h-4" />
          </div>
        </div>
      </div>
    </div>;
}