import React, { useState } from 'react';
import { ChevronLeftIcon, ShareIcon, CheckCircleIcon, TagIcon, CalendarIcon, UserIcon, DollarSignIcon, AlertCircleIcon, AlertTriangleIcon, InfoIcon, ClockIcon } from 'lucide-react';
export interface Posting {
  id: string;
  title: string;
  postedBy: string;
  posterInitials: string;
  posterColor: string;
  date: string;
  urgency: 'urgent' | 'important' | 'info';
  skills: string[];
  description: string;
  compensation: string;
  deadline: string;
  status: 'open' | 'claimed';
  claimedBy?: string;
}
interface PostingDetailScreenProps {
  posting: Posting;
  onBack: () => void;
}
const urgencyConfig = {
  urgent: {
    label: 'Urgent',
    bg: '#fee2e2',
    text: '#dc2626',
    icon: <AlertCircleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  important: {
    label: 'Important',
    bg: '#fef3c7',
    text: '#b45309',
    icon: <AlertTriangleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  },
  info: {
    label: 'Open',
    bg: '#e8f0fb',
    text: '#2B7FE0',
    icon: <InfoIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
  }
};
export function PostingDetailScreen({
  posting,
  onBack
}: PostingDetailScreenProps) {
  const [claimed, setClaimed] = useState(posting.status === 'claimed');
  const [forwarded, setForwarded] = useState(false);
  const urgency = urgencyConfig[posting.urgency];
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Nav */}
        <div className="flex items-center px-4 py-2 border-b" style={{
        backgroundColor: '#F0F2F5',
        borderColor: '#E5E7EB'
      }}>
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#10B981'
        }}>
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Postings</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto" style={{
        scrollbarWidth: 'none'
      }}>
          {/* Header */}
          <div className="px-5 pt-5 pb-5" style={{
          backgroundColor: '#FFFFFF'
        }}>
            <div className="flex items-center justify-between mb-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full" style={{
              backgroundColor: urgency.bg,
              color: urgency.text
            }}>
                {urgency.icon}
                <span className="text-[12px] font-bold uppercase tracking-wide">
                  {urgency.label}
                </span>
              </div>
              {claimed && <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[12px] font-bold" style={{
              backgroundColor: '#D1FAE5',
              color: '#065F46'
            }}>
                  <CheckCircleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />
                  Claimed
                </span>}
            </div>

            <h1 className="text-[22px] font-bold text-gray-900 leading-snug mb-4">
              {posting.title}
            </h1>

            {/* Poster */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{
              backgroundColor: posting.posterColor
            }}>
                <span className="text-[13px] font-bold text-white">
                  {posting.posterInitials}
                </span>
              </div>
              <div className="flex-1">
                <p className="text-[15px] font-semibold text-gray-900">
                  {posting.postedBy}
                </p>
                <p className="text-[12px] text-gray-400">
                  Posted {posting.date}
                </p>
              </div>
            </div>
          </div>

          <div className="px-4 py-4 space-y-3">
            {/* Meta info */}
            <div className="rounded-2xl overflow-hidden shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <div className="flex items-center gap-3 px-4 py-3.5 border-b border-gray-100">
                <CalendarIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2} />
                <span className="text-[13px] text-gray-500 w-20 flex-shrink-0">
                  Deadline
                </span>
                <span className="text-[14px] font-semibold text-gray-900">
                  {posting.deadline}
                </span>
              </div>
              
              <div className="flex items-start gap-3 px-4 py-3.5">
                <TagIcon className="w-4 h-4 text-gray-400 flex-shrink-0 mt-0.5" strokeWidth={2} />
                <span className="text-[13px] text-gray-500 w-20 flex-shrink-0 mt-0.5">
                  Skills
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {posting.skills.map((s) => <span key={s} className="px-2.5 py-1 rounded-full text-[12px] font-medium" style={{
                  backgroundColor: '#fce7f3',
                  color: '#be185d'
                }}>
                      {s}
                    </span>)}
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="rounded-2xl px-4 py-4 shadow-sm" style={{
            backgroundColor: '#FFFFFF'
          }}>
              <p className="text-[12px] font-semibold text-gray-400 uppercase tracking-wide mb-2">
                Description
              </p>
              <p className="text-[15px] text-gray-700 leading-relaxed">
                {posting.description}
              </p>
            </div>

            {/* Forward info card */}
            <div className="rounded-2xl px-4 py-3.5 shadow-sm" style={{
            backgroundColor: '#f0fdf4',
            border: '1.5px solid #bbf7d0'
          }}>
              <div className="flex items-start gap-2">
                <ShareIcon className="w-4 h-4 mt-0.5 flex-shrink-0" style={{
                color: '#16a34a'
              }} strokeWidth={2} />
                <div>
                  <p className="text-[13px] font-semibold" style={{
                  color: '#15803d'
                }}>
                    Know someone perfect for this?
                  </p>
                  <p className="text-[12px] mt-0.5" style={{
                  color: '#166534'
                }}>
                    Forward this gig to a friend — they don't need to be a club
                    member to apply.
                  </p>
                </div>
              </div>
            </div>

            <div className="h-2" />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center gap-3 px-4 py-4 border-t" style={{
        paddingBottom: '28px',
        backgroundColor: '#FFFFFF',
        borderColor: '#E5E7EB'
      }}>
          {/* Forward button */}
          <button onClick={() => setForwarded(!forwarded)} className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-full font-semibold text-[15px] border-2 transition-all duration-200 flex-shrink-0" style={{
          borderColor: forwarded ? '#10B981' : '#10B981',
          color: forwarded ? '#065F46' : '#10B981',
          backgroundColor: forwarded ? '#D1FAE5' : 'white'
        }}>
            <ShareIcon className="w-4 h-4" strokeWidth={2.5} />
            {forwarded ? 'Forwarded!' : 'Forward'}
          </button>

          {/* Claim / Apply button */}
          <button onClick={() => setClaimed(!claimed)} className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full font-semibold text-[16px] transition-all duration-200" style={{
          backgroundColor: claimed ? '#D1FAE5' : '#10B981',
          color: claimed ? '#065F46' : 'white',
          border: claimed ? '1.5px solid #10B981' : 'none'
        }}>
            <CheckCircleIcon className="w-5 h-5" strokeWidth={2.5} />
            {claimed ? 'Task Claimed ✓' : 'Claim Task'}
          </button>
        </div>
      </div>
    </div>;
}