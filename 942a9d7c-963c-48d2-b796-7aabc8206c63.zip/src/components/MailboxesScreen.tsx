import React, { useState } from 'react';
import { InboxIcon, ArchiveIcon, FileTextIcon, SendIcon, Trash2Icon, ChevronRightIcon, ChevronDownIcon, LayersIcon, TypeIcon, TriangleIcon, PenToolIcon, ZapIcon, HeartIcon, EyeIcon, BookmarkIcon, MessageCircleIcon } from 'lucide-react';
import { GlobalTabBar } from './GlobalTabBar';
interface MailboxesScreenProps {
  onNavigateToInboxes: () => void;
  onNavigateToInbox: () => void;
  onNavigateHome: () => void;
  onNavigateAccount: () => void;
}
const BLUE = '#06B6D4';
const myClubs = [{
  id: 'mcs',
  label: 'Media Creative Society',
  subtitle: 'All inboxes · Updated just now',
  icon: <LayersIcon className="w-5 h-5 text-white" strokeWidth={1.8} />,
  iconBg: '#4F46E5',
  badge: '3',
  navigable: true
}, {
  id: 'typography',
  label: 'Typography Club',
  subtitle: 'Active tasks & announcements',
  icon: <TypeIcon className="w-5 h-5 text-white" strokeWidth={1.8} />,
  iconBg: '#F06292',
  badge: null,
  navigable: false
}, {
  id: 'architecture',
  label: 'Architecture Club',
  subtitle: 'Coordination & design threads',
  icon: <TriangleIcon className="w-5 h-5 text-white" strokeWidth={1.8} />,
  iconBg: '#06B6D4',
  badge: null,
  navigable: false
}, {
  id: 'graphics',
  label: 'Graphics Club',
  subtitle: 'Design outputs & internal posts',
  icon: <PenToolIcon className="w-5 h-5 text-white" strokeWidth={1.8} />,
  iconBg: '#8B5CF6',
  badge: null,
  navigable: false
}, {
  id: 'football',
  label: 'Football Flava',
  subtitle: 'Social & athletic participation',
  icon: <ZapIcon className="w-5 h-5 text-white" strokeWidth={1.8} />,
  iconBg: '#10B981',
  badge: null,
  navigable: false
}];
const icloudMailboxes = [{
  id: 'inbox',
  label: 'Inbox',
  icon: <InboxIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />,
  muted: false
}, {
  id: 'academic',
  label: 'Academic Portfolio',
  icon: <FileTextIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />,
  muted: false
}, {
  id: 'creative',
  label: 'Creative Work',
  icon: <SendIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />,
  muted: false
}, {
  id: 'resume',
  label: 'Resume',
  icon: <ArchiveIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />,
  muted: false
}, {
  id: 'reposts',
  label: 'Reposts',
  icon: <Trash2Icon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />,
  muted: false
}];
const insightsMailboxes = [{
  id: 'likes',
  label: 'Likes',
  icon: <HeartIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />
}, {
  id: 'views',
  label: 'Views',
  icon: <EyeIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />
}, {
  id: 'collections',
  label: 'Collections',
  icon: <BookmarkIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />
}, {
  id: 'comments',
  label: 'Comments',
  icon: <MessageCircleIcon className="w-6 h-6" style={{
    color: BLUE
  }} strokeWidth={1.8} />
}];
export function MailboxesScreen({
  onNavigateToInboxes,
  onNavigateToInbox,
  onNavigateHome,
  onNavigateAccount
}: MailboxesScreenProps) {
  const [accountExpanded, setAccountExpanded] = useState(true);
  const [clubsExpanded, setClubsExpanded] = useState(true);
  const [insightsExpanded, setInsightsExpanded] = useState(true);
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      {/* Phone frame */}
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Identity Header */}
        <div className="px-6 pt-6 pb-6" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 rounded-full flex items-center justify-center border-2 border-white shadow-sm" style={{
            backgroundColor: '#4F46E5'
          }}>
              <span className="text-[26px] font-bold text-white select-none">
                KF
              </span>
            </div>
          </div>
          <h1 className="text-[32px] font-bold text-gray-900 leading-tight tracking-tight text-center">
            Karl Fog
          </h1>
          <div className="flex items-center justify-center gap-1 mt-1.5">
            <p className="text-[13px] text-gray-400 leading-snug">
              Cape Town, South Africa
            </p>
          </div>
          <div className="flex items-center justify-center gap-1 mt-0.5">
            <p className="text-[13px] text-gray-400 leading-snug">
              2nd Year Architecture
            </p>
          </div>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto pb-4" style={{
        scrollbarWidth: 'none',
        backgroundColor: '#F8F9FA'
      }}>
          {/* MY CLUBS section header */}
          <div className="flex items-center justify-between px-5 mb-2 pt-5">
            <span className="text-[13px] font-semibold uppercase tracking-widest" style={{
            color: '#9ca3af'
          }}>
              My Clubs
            </span>
            <button onClick={() => setClubsExpanded(!clubsExpanded)} className="w-7 h-7 rounded-full flex items-center justify-center" style={{
            backgroundColor: 'transparent'
          }} aria-label={clubsExpanded ? 'Collapse My Clubs' : 'Expand My Clubs'}>
              <ChevronDownIcon className="w-4 h-4 transition-transform duration-200" strokeWidth={2.5} style={{
              color: '#9ca3af',
              transform: clubsExpanded ? 'rotate(0deg)' : 'rotate(-90deg)'
            }} />
            </button>
          </div>

          {clubsExpanded && <div className="mx-4 bg-white rounded-2xl overflow-hidden mb-5 shadow-sm">
              {myClubs.map((club, index) => <div key={club.id}>
                  <button onClick={club.navigable ? onNavigateToInboxes : undefined} className="w-full flex items-center justify-between px-5 py-4 active:bg-gray-50 transition-colors">
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-[16px] font-semibold text-gray-900 truncate">
                        {club.label}
                      </p>
                      <p className="text-[12px] text-gray-400 truncate mt-0.5">
                        {club.subtitle}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0 ml-3">
                      {club.badge && <span className="text-[12px] font-bold text-white px-2 py-0.5 rounded-full" style={{
                  backgroundColor: '#FF2D78'
                }}>
                          {club.badge}
                        </span>}
                      <ChevronRightIcon className="w-4 h-4 text-gray-300" strokeWidth={2} />
                    </div>
                  </button>
                  {index < myClubs.length - 1 && <div className="border-t border-gray-100 mx-5" />}
                </div>)}
            </div>}

          {/* MY LEDGER section header */}
          <div className="flex items-center justify-between px-5 mb-2 pt-2">
            <span className="text-[13px] font-semibold uppercase tracking-widest" style={{
            color: '#9ca3af'
          }}>
              My Ledger
            </span>
            <button onClick={() => setAccountExpanded(!accountExpanded)} className="w-7 h-7 rounded-full flex items-center justify-center" aria-label={accountExpanded ? 'Collapse account' : 'Expand account'}>
              <ChevronDownIcon className="w-4 h-4 transition-transform duration-200" strokeWidth={2.5} style={{
              color: '#9ca3af',
              transform: accountExpanded ? 'rotate(0deg)' : 'rotate(-90deg)'
            }} />
            </button>
          </div>

          {accountExpanded && <div className="mx-4 bg-white rounded-2xl overflow-hidden mb-5 shadow-sm">
              {icloudMailboxes.map((item, index) => <div key={item.id}>
                  <button onClick={item.id === 'inbox' ? onNavigateToInbox : undefined} className="w-full flex items-center justify-between px-5 py-4 transition-colors active:bg-gray-50">
                    <span className="text-[16px] font-medium text-left" style={{
                color: item.muted ? '#9ca3af' : '#111827'
              }}>
                      {item.label}
                    </span>
                    <ChevronRightIcon className="w-4 h-4 text-gray-300 flex-shrink-0" strokeWidth={2} />
                  </button>
                  {index < icloudMailboxes.length - 1 && <div className="border-t border-gray-100 mx-5" />}
                </div>)}
            </div>}

          {/* INSIGHTS section header */}
          <div className="flex items-center justify-between px-5 mb-2 pt-2">
            <span className="text-[13px] font-semibold uppercase tracking-widest" style={{
            color: '#9ca3af'
          }}>
              Insights
            </span>
            <button onClick={() => setInsightsExpanded(!insightsExpanded)} className="w-7 h-7 rounded-full flex items-center justify-center" aria-label={insightsExpanded ? 'Collapse Insights' : 'Expand Insights'}>
              <ChevronDownIcon className="w-4 h-4 transition-transform duration-200" strokeWidth={2.5} style={{
              color: '#9ca3af',
              transform: insightsExpanded ? 'rotate(0deg)' : 'rotate(-90deg)'
            }} />
            </button>
          </div>

          {insightsExpanded && <div className="mx-4 bg-white rounded-2xl overflow-hidden mb-5 shadow-sm">
              {insightsMailboxes.map((item, index) => <div key={item.id}>
                  <button className="w-full flex items-center justify-between px-5 py-4 transition-colors active:bg-gray-50">
                    <span className="text-[16px] font-medium text-left" style={{
                color: '#111827'
              }}>
                      {item.label}
                    </span>
                    <ChevronRightIcon className="w-4 h-4 text-gray-300 flex-shrink-0" strokeWidth={2} />
                  </button>
                  {index < insightsMailboxes.length - 1 && <div className="border-t border-gray-100 mx-5" />}
                </div>)}
            </div>}
        </div>

        {/* Global Tab Bar */}
        <GlobalTabBar activeTab="mailboxes" onNavigateHome={onNavigateHome} onNavigateMailboxes={() => {}} onNavigateAccount={onNavigateAccount} />
      </div>
    </div>;
}