import React, { useEffect, useState, useRef } from 'react';
import { ChevronLeftIcon, SendIcon } from 'lucide-react';
import type { Conversation, Message } from './InboxScreen';
interface ConversationScreenProps {
  conversation: Conversation;
  onBack: () => void;
}
export function ConversationScreen({
  conversation,
  onBack
}: ConversationScreenProps) {
  const [messages, setMessages] = useState<Message[]>(conversation.messages);
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: 'smooth'
    });
  }, [messages]);
  const handleSend = () => {
    const trimmed = inputText.trim();
    if (!trimmed) return;
    const newMsg: Message = {
      id: String(Date.now()),
      text: trimmed,
      sender: 'me',
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      })
    };
    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSend();
  };
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#FFFFFF'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <button onClick={onBack} className="flex items-center gap-1 flex-shrink-0" style={{
          color: '#4b5563'
        }} aria-label="Back to inbox">
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[15px] font-medium">Inbox</span>
          </button>

          <div className="flex-1 text-center">
            {/* Avatar */}
            <div className="flex justify-center mb-0.5">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{
              backgroundColor: '#E5E7EB'
            }}>
                <span className="text-[13px] font-bold" style={{
                color: '#4B5563'
              }}>
                  {conversation.name.slice(0, 2).toUpperCase()}
                </span>
              </div>
            </div>
            <p className="text-[14px] font-semibold" style={{
            color: '#1A1D23'
          }}>
              {conversation.name}
            </p>
            
          </div>

          {/* Spacer to balance back button */}
          <div style={{
          width: '64px'
        }} />
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3" style={{
        backgroundColor: '#F8F9FA',
        scrollbarWidth: 'none'
      }}>
          {messages.map((msg) => {
          const isMe = msg.sender === 'me';
          return <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                <div className="max-w-[72%]">
                  <div className="px-4 py-2.5 rounded-2xl" style={{
                backgroundColor: isMe ? '#1A1D23' : '#FFFFFF',
                color: isMe ? '#FFFFFF' : '#1A1D23',
                borderRadius: isMe ? '18px 18px 4px 18px' : '18px 18px 18px 4px',
                boxShadow: isMe ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
                border: isMe ? 'none' : '1px solid #E5E7EB'
              }}>
                    <p className="text-[14px] leading-relaxed">{msg.text}</p>
                  </div>
                  <p className={`text-[11px] mt-1 ${isMe ? 'text-right' : 'text-left'}`} style={{
                color: '#9CA3AF'
              }}>
                    {msg.time}
                  </p>
                </div>
              </div>;
        })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-t border-gray-100" style={{
        paddingBottom: '28px',
        backgroundColor: '#FFFFFF'
      }}>
          <input type="text" value={inputText} onChange={(e) => setInputText(e.target.value)} onKeyDown={handleKeyDown} placeholder="Type a message..." className="flex-1 px-4 py-2.5 rounded-full text-[14px] outline-none" style={{
          backgroundColor: '#F3F4F6',
          color: '#1A1D23',
          border: '1px solid #E5E7EB'
        }} aria-label="Type a message" />
          <button onClick={handleSend} disabled={!inputText.trim()} className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-all" style={{
          backgroundColor: inputText.trim() ? '#1A1D23' : '#E5E7EB',
          color: inputText.trim() ? '#FFFFFF' : '#9CA3AF'
        }} aria-label="Send message">
            <SendIcon className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>
      </div>
    </div>;
}