import React from 'react';
import { ChevronLeftIcon, LinkedinIcon, MessageCircleIcon, CalendarIcon } from 'lucide-react';
export interface Member {
  id: string;
  name: string;
  role: string;
  joinedDate: string;
  avatarInitials: string;
  avatarColor: string;
  skills: string[];
  about: string;
  privateNotes: string;
}
interface MemberProfileScreenProps {
  member: Member;
  isAdmin?: boolean;
  onBack: () => void;
}
export function MemberProfileScreen({
  member,
  isAdmin = true,
  onBack
}: MemberProfileScreenProps) {
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#F8F9FA'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Nav Bar */}
        <div className="flex items-center px-4 py-2 bg-gray-50">
          <button onClick={onBack} className="flex items-center gap-1" style={{
          color: '#8B5CF6'
        }} aria-label="Back to Members">
            <ChevronLeftIcon className="w-5 h-5" strokeWidth={2.5} />
            <span className="text-[16px] font-medium">Members</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto pb-6" style={{
        scrollbarWidth: 'none'
      }}>
          {/* Avatar + Name Header */}
          <div className="flex flex-col items-center pt-6 pb-6 px-5" style={{
          backgroundColor: '#F0F2F5'
        }}>
            <div className="w-24 h-24 rounded-full flex items-center justify-center mb-4 shadow-sm" style={{
            backgroundColor: member.avatarColor
          }}>
              <span className="text-[32px] font-bold text-white">
                {member.avatarInitials}
              </span>
            </div>
            <h1 className="text-[24px] font-bold text-gray-900 text-center">
              {member.name}
            </h1>
            <p className="text-[14px] text-gray-400 mt-1 flex items-center gap-1">
              <CalendarIcon className="w-3.5 h-3.5" strokeWidth={2} />
              Joined {member.joinedDate}
            </p>
          </div>

          {/* ── BENTO BOX PROJECTS ── */}
          <div className="px-4 pt-4 pb-4">
            <p className="text-[13px] font-bold uppercase tracking-widest mb-3" style={{
            color: '#1A1D23'
          }}>
              Projects
            </p>

            <div className="flex flex-col gap-2">
              {/* ROW 1: Full-width featured card */}
              <div className="relative w-full rounded-2xl overflow-hidden flex flex-col justify-between p-4" style={{
              height: '148px',
              backgroundColor: '#1e1b4b'
            }}>
                <div className="absolute bottom-0 right-0 w-28 h-28 rounded-full opacity-20" style={{
                border: '18px solid #7C3AED',
                transform: 'translate(30%, 30%)'
              }} />
                <div className="absolute bottom-0 right-0 w-44 h-44 rounded-full opacity-10" style={{
                border: '18px solid #7C3AED',
                transform: 'translate(30%, 30%)'
              }} />
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wide" style={{
                  backgroundColor: 'rgba(124,58,237,0.35)',
                  color: '#C4B5FD'
                }}>
                    Featured
                  </span>
                  <span className="text-[11px]" style={{
                  color: 'rgba(255,255,255,0.4)'
                }}>
                    Studio III · 2024
                  </span>
                </div>
                <div>
                  <p className="text-[19px] font-bold text-white leading-tight">
                    Spring Showcase 2024
                  </p>
                  <p className="text-[12px] mt-0.5" style={{
                  color: 'rgba(255,255,255,0.5)'
                }}>
                    Annual end-of-year showcase · Lead: {member.name}
                  </p>
                </div>
              </div>

              {/* ROW 2: Two asymmetric cards */}
              <div className="flex gap-2">
                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3.5" style={{
                flex: '1.15',
                height: '120px',
                backgroundColor: '#0d3d3d'
              }}>
                  <div className="absolute bottom-0 right-0 w-20 h-20 rounded-full opacity-20" style={{
                  border: '14px solid #0891B2',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="self-start px-2 py-0.5 rounded-full text-[10px] font-bold uppercase" style={{
                  backgroundColor: 'rgba(8,145,178,0.3)',
                  color: '#67E8F9'
                }}>
                    In Progress
                  </span>
                  <div>
                    <p className="text-[14px] font-bold text-white leading-snug">
                      Recruitment Campaign
                    </p>
                    <p className="text-[11px] mt-0.5" style={{
                    color: 'rgba(255,255,255,0.45)'
                  }}>
                      Fall 2024
                    </p>
                  </div>
                </div>

                <div className="relative rounded-2xl overflow-hidden flex flex-col justify-between p-3.5" style={{
                flex: '0.85',
                height: '120px',
                backgroundColor: '#1a2e1a'
              }}>
                  <div className="absolute bottom-0 right-0 w-16 h-16 rounded-full opacity-25" style={{
                  border: '12px solid #059669',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="self-start px-2 py-0.5 rounded-full text-[10px] font-bold uppercase" style={{
                  backgroundColor: 'rgba(5,150,105,0.3)',
                  color: '#6EE7B7'
                }}>
                    Completed
                  </span>
                  <div>
                    <p className="text-[13px] font-bold text-white leading-snug">
                      Website Redesign
                    </p>
                    <p className="text-[11px] mt-0.5" style={{
                    color: 'rgba(255,255,255,0.45)'
                  }}>
                      2023
                    </p>
                  </div>
                </div>
              </div>

              {/* ROW 3: Three small equal cards */}
              <div className="flex gap-2">
                <div className="relative flex-1 rounded-2xl overflow-hidden flex flex-col justify-between p-3" style={{
                height: '96px',
                backgroundColor: '#0f1f3d'
              }}>
                  <div className="absolute bottom-0 right-0 w-14 h-14 rounded-full opacity-20" style={{
                  border: '10px solid #3B82F6',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="text-[9px] font-bold uppercase" style={{
                  color: 'rgba(147,197,253,0.7)'
                }}>
                    Research
                  </span>
                  <p className="text-[12px] font-bold text-white leading-snug">
                    Brand Identity
                  </p>
                </div>

                <div className="relative flex-1 rounded-2xl overflow-hidden flex flex-col justify-between p-3" style={{
                height: '96px',
                backgroundColor: '#2d1040'
              }}>
                  <div className="absolute bottom-0 right-0 w-14 h-14 rounded-full opacity-20" style={{
                  border: '10px solid #8B5CF6',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="text-[9px] font-bold uppercase" style={{
                  color: 'rgba(196,181,253,0.7)'
                }}>
                    Events
                  </span>
                  <p className="text-[12px] font-bold text-white leading-snug">
                    Workshop Series
                  </p>
                </div>

                <div className="relative flex-1 rounded-2xl overflow-hidden flex flex-col justify-between p-3" style={{
                height: '96px',
                backgroundColor: '#1a1a2e'
              }}>
                  <div className="absolute bottom-0 right-0 w-14 h-14 rounded-full opacity-20" style={{
                  border: '10px solid #6366F1',
                  transform: 'translate(35%, 35%)'
                }} />
                  <span className="text-[9px] font-bold uppercase" style={{
                  color: 'rgba(165,180,252,0.7)'
                }}>
                    Media
                  </span>
                  <p className="text-[12px] font-bold text-white leading-snug">
                    Social Campaign
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ── COLLABORATORS ── */}
          <div className="px-4 pb-4">
            <p className="text-[13px] font-bold uppercase tracking-widest mb-3" style={{
            color: '#1A1D23'
          }}>
              Collaborators
            </p>
            <div className="flex items-center gap-3 overflow-x-auto" style={{
            scrollbarWidth: 'none'
          }}>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{
                backgroundColor: '#8B5CF6'
              }}>
                  <span className="text-[14px] font-bold text-white">AC</span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  Alex C.
                </span>
              </div>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{
                backgroundColor: '#F97316'
              }}>
                  <span className="text-[14px] font-bold text-white">JL</span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  Jordan L.
                </span>
              </div>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{
                backgroundColor: '#06B6D4'
              }}>
                  <span className="text-[14px] font-bold text-white">SR</span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  Sam R.
                </span>
              </div>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{
                backgroundColor: '#10B981'
              }}>
                  <span className="text-[14px] font-bold text-white">MP</span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  Maya P.
                </span>
              </div>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{
                backgroundColor: '#FB7185'
              }}>
                  <span className="text-[14px] font-bold text-white">DK</span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  Denise K.
                </span>
              </div>
              <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div className="w-12 h-12 rounded-full flex items-center justify-center border-2 border-dashed" style={{
                borderColor: '#D1D5DB',
                backgroundColor: '#F9FAFB'
              }}>
                  <span className="text-[12px] font-bold" style={{
                  color: '#9CA3AF'
                }}>
                    +4
                  </span>
                </div>
                <span className="text-[10px] font-medium" style={{
                color: '#6B7280'
              }}>
                  more
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="flex items-center gap-3 px-4 py-4 border-t" style={{
        paddingBottom: '28px',
        backgroundColor: '#FFFFFF',
        borderColor: '#E5E7EB'
      }}>
          <button className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full font-semibold text-[16px] text-white transition-opacity active:opacity-80" style={{
          backgroundColor: '#8B5CF6'
        }} aria-label="Message member">
            <MessageCircleIcon className="w-5 h-5" strokeWidth={2} />
            Message
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full font-semibold text-[16px] border-2 transition-opacity active:opacity-80" style={{
          borderColor: '#06B6D4',
          color: '#06B6D4'
        }} aria-label="View LinkedIn profile">
            <LinkedinIcon className="w-5 h-5" strokeWidth={2} />
            LinkedIn
          </button>
        </div>
      </div>
    </div>;
}