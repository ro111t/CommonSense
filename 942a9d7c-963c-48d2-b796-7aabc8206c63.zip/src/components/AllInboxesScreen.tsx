import React, { useEffect, useState, useRef } from 'react';
import { ChevronLeftIcon, MoreHorizontalIcon, UserIcon, BriefcaseIcon, BellIcon, ClipboardListIcon, CalendarIcon, ChevronRightIcon, CheckCircleIcon, ClockIcon, LightbulbIcon, AlertCircleIcon, AlertTriangleIcon, InfoIcon, PlusIcon, XIcon } from 'lucide-react';
import type { Member } from './MemberProfileScreen';
import type { Project } from './ProjectDetailScreen';
import type { Announcement } from './AnnouncementDetailScreen';
import type { Posting } from './PostingDetailScreen';
import type { CalendarEvent } from './CalendarEventDetailScreen';
type FilterTab = 'members' | 'projects' | 'announcements' | 'postings' | 'calendar';
const tabs: {
  id: FilterTab;
  label: string;
  icon: React.ReactNode;
  activeColor: string;
}[] = [{
  id: 'members',
  label: 'Members',
  icon: <UserIcon className="w-5 h-5" strokeWidth={2} />,
  activeColor: '#8B5CF6'
}, {
  id: 'projects',
  label: 'Projects',
  icon: <BriefcaseIcon className="w-5 h-5" strokeWidth={2} />,
  activeColor: '#06B6D4'
}, {
  id: 'announcements',
  label: 'Announcements',
  icon: <BellIcon className="w-5 h-5" strokeWidth={2} />,
  activeColor: '#F97316'
}, {
  id: 'postings',
  label: 'Postings',
  icon: <ClipboardListIcon className="w-5 h-5" strokeWidth={2} />,
  activeColor: '#10B981'
}, {
  id: 'calendar',
  label: 'Calendar',
  icon: <CalendarIcon className="w-5 h-5" strokeWidth={2} />,
  activeColor: '#FB7185'
}];
export const sampleMembers: Member[] = [{
  id: '1',
  name: 'Alex Chen',
  role: 'VP of Design',
  joinedDate: 'September 2023',
  avatarInitials: 'AC',
  avatarColor: '#8B5CF6',
  skills: ['Figma', 'Branding', 'Motion', 'Illustration'],
  about: 'Design lead for all club visuals and event branding. Passionate about accessible design and creative storytelling.',
  privateNotes: 'Excellent at leading design sprints. Reliable for tight deadlines. Prefers async communication over meetings.'
}, {
  id: '2',
  name: 'Jordan Lee',
  role: 'Events Coordinator',
  joinedDate: 'January 2024',
  avatarInitials: 'JL',
  avatarColor: '#F97316',
  skills: ['Event Planning', 'Logistics', 'Social Media', 'Outreach'],
  about: 'Organizes all club events from concept to execution. Has coordinated 12+ events this academic year.',
  privateNotes: 'Very organized. Good at Python for data tracking. Available most evenings and weekends.'
}, {
  id: '3',
  name: 'Sam Rivera',
  role: 'Lead Developer',
  joinedDate: 'October 2022',
  avatarInitials: 'SR',
  avatarColor: '#06B6D4',
  skills: ['React', 'Python', 'Node.js', 'AWS'],
  about: "Builds and maintains the club's internal tools and web presence. Mentors newer members on software projects.",
  privateNotes: 'Strong Python skills, reliable for late shifts. Has expressed interest in officer role next semester.'
}, {
  id: '4',
  name: 'Maya Patel',
  role: 'Marketing Director',
  joinedDate: 'March 2023',
  avatarInitials: 'MP',
  avatarColor: '#10B981',
  skills: ['Copywriting', 'Analytics', 'Canva', 'Email Campaigns'],
  about: "Drives all outreach and promotional strategy. Grew the club's Instagram following by 300% in one semester.",
  privateNotes: 'Creative and self-motivated. Needs clear deadlines to stay on track. Great for high-visibility projects.'
}];
export const sampleProjects: Project[] = [{
  id: '1',
  name: 'Spring Showcase 2024',
  leadMember: 'Alex Chen',
  leadAvatarInitials: 'AC',
  leadAvatarColor: '#06B6D4',
  status: 'Completed',
  date: 'Mar 2024',
  tagline: 'Annual end-of-year showcase featuring member work.',
  description: 'A full-scale showcase event featuring 30+ projects from club members across design, engineering, and media. Coordinated venue logistics, sponsor outreach, and live demos over a 3-month planning cycle.',
  highlights: ['200+ attendees across two sessions', 'Featured 8 industry sponsors', 'Live demo stations for 12 projects', 'Covered by the Daily Bruin student paper'],
  attachments: [{
    name: 'Event Recap Report',
    type: 'pdf',
    size: '2.4 MB'
  }, {
    name: 'Showcase Photos',
    type: 'images',
    size: '148 MB'
  }, {
    name: 'Highlight Reel',
    type: 'video',
    size: '312 MB'
  }]
}, {
  id: '2',
  name: 'Recruitment Campaign',
  leadMember: 'Maya Patel',
  leadAvatarInitials: 'MP',
  leadAvatarColor: '#10B981',
  status: 'Completed',
  date: 'Sep 2023',
  tagline: 'Fall recruitment drive to grow club membership.',
  description: 'Designed and executed a multi-channel recruitment campaign targeting incoming freshmen and transfer students. Included tabling events, Instagram reels, and a redesigned club brochure.',
  highlights: ['Grew membership from 45 to 112 members', 'Instagram reach increased by 300%', '6 tabling events across campus', 'New member onboarding guide created'],
  attachments: [{
    name: 'Campaign Strategy Deck',
    type: 'pdf',
    size: '5.1 MB'
  }, {
    name: 'Recruitment Flyers',
    type: 'images',
    size: '22 MB'
  }, {
    name: 'Onboarding Guide',
    type: 'doc',
    size: '890 KB'
  }]
}, {
  id: '3',
  name: 'Club Website Redesign',
  leadMember: 'Sam Rivera',
  leadAvatarInitials: 'SR',
  leadAvatarColor: '#06B6D4',
  status: 'In Progress',
  date: 'Apr 2024',
  tagline: "Rebuilding the club's public-facing website from scratch.",
  description: 'Full redesign and rebuild of the club website using React and Tailwind CSS. New features include a member directory, project portfolio, and event calendar. Currently in beta testing.',
  highlights: ['Mobile-first responsive design', 'Member directory with search & filters', 'Integrated Google Calendar for events', 'Targeting launch before Fall 2024'],
  attachments: [{
    name: 'Design Mockups',
    type: 'images',
    size: '34 MB'
  }, {
    name: 'Technical Spec',
    type: 'doc',
    size: '1.2 MB'
  }]
}];
export const sampleAnnouncements: Announcement[] = [{
  id: '1',
  title: 'General Meeting This Friday — Attendance Required',
  sender: 'Jordan Lee',
  senderInitials: 'JL',
  senderColor: '#F97316',
  date: 'Today, 10:42 AM',
  urgency: 'urgent',
  body: "All active members must attend this Friday's general meeting at 6:00 PM in Boelter Hall 3400. We will be voting on the Spring Showcase budget and assigning project leads. Please confirm your attendance below.",
  type: 'attendance',
  totalMembers: 45,
  readReceipts: [{
    name: 'Alex Chen',
    initials: 'AC',
    color: '#8B5CF6',
    readAt: '10:44 AM'
  }, {
    name: 'Sam Rivera',
    initials: 'SR',
    color: '#06B6D4',
    readAt: '10:51 AM'
  }, {
    name: 'Maya Patel',
    initials: 'MP',
    color: '#10B981',
    readAt: '11:02 AM'
  }, {
    name: 'Chris Wong',
    initials: 'CW',
    color: '#f59e0b',
    readAt: '11:15 AM'
  }, {
    name: 'Priya Nair',
    initials: 'PN',
    color: '#8B5CF6',
    readAt: '11:30 AM'
  }, {
    name: 'Daniel Kim',
    initials: 'DK',
    color: '#06B6D4',
    readAt: '12:04 PM'
  }]
}, {
  id: '2',
  title: 'New Project Submissions Open — Spring Showcase',
  sender: 'Alex Chen',
  senderInitials: 'AC',
  senderColor: '#8B5CF6',
  date: 'Yesterday, 3:15 PM',
  urgency: 'important',
  body: 'Project submissions for the Spring Showcase are now open. Submit your project proposal via the club portal by March 10th. Each submission should include a title, description, team members, and required resources.',
  type: 'info',
  totalMembers: 45,
  readReceipts: [{
    name: 'Jordan Lee',
    initials: 'JL',
    color: '#F97316',
    readAt: 'Yesterday'
  }, {
    name: 'Sam Rivera',
    initials: 'SR',
    color: '#06B6D4',
    readAt: 'Yesterday'
  }, {
    name: 'Maya Patel',
    initials: 'MP',
    color: '#10B981',
    readAt: 'Yesterday'
  }]
}, {
  id: '3',
  title: 'Officer Applications Now Live for Next Semester',
  sender: 'Maya Patel',
  senderInitials: 'MP',
  senderColor: '#10B981',
  date: 'Mon, Feb 24',
  urgency: 'info',
  body: 'Applications for officer positions (President, VP, Treasurer, Events Lead) are now open for the Fall 2024 semester. Apply via the club website. Deadline is March 20th. All current members in good standing are eligible.',
  type: 'info',
  totalMembers: 45,
  readReceipts: [{
    name: 'Alex Chen',
    initials: 'AC',
    color: '#8B5CF6',
    readAt: 'Mon'
  }, {
    name: 'Jordan Lee',
    initials: 'JL',
    color: '#F97316',
    readAt: 'Mon'
  }, {
    name: 'Sam Rivera',
    initials: 'SR',
    color: '#06B6D4',
    readAt: 'Tue'
  }, {
    name: 'Chris Wong',
    initials: 'CW',
    color: '#f59e0b',
    readAt: 'Tue'
  }]
}];
export const samplePostings: Posting[] = [{
  id: '1',
  title: 'Flyer Designer Needed',
  postedBy: 'Alex Chen',
  posterInitials: 'AC',
  posterColor: '#8B5CF6',
  date: 'Today',
  urgency: 'urgent',
  skills: ['Figma', 'Illustrator', 'Typography'],
  description: 'We need a flyer for the Spring Showcase by this Friday. The design should match our club branding (blue + white). Reference materials and brand kit will be provided. Estimated 2–3 hours of work.',
  compensation: 'Club credit + portfolio feature',
  deadline: 'Due Mar 5',
  status: 'open'
}, {
  id: '2',
  title: 'Social Media Graphics — Recruitment Drive',
  postedBy: 'Maya Patel',
  posterInitials: 'MP',
  posterColor: '#10B981',
  date: 'Yesterday',
  urgency: 'important',
  skills: ['Canva', 'Instagram', 'Copywriting'],
  description: 'Create 3 Instagram carousel posts for our fall recruitment campaign. Content brief will be shared. Should feel energetic and welcoming to incoming students.',
  compensation: 'Shoutout + resume line item',
  deadline: 'Due Mar 8',
  status: 'open'
}, {
  id: '3',
  title: 'Event Photographer',
  postedBy: 'Jordan Lee',
  posterInitials: 'JL',
  posterColor: '#F97316',
  date: 'Mon, Feb 24',
  urgency: 'info',
  skills: ['Photography', 'Lightroom', 'Event Coverage'],
  description: 'Looking for a photographer to cover our General Meeting on March 3rd. Photos will be used in the club newsletter and website. DSLR or mirrorless camera preferred.',
  compensation: 'Free club merch + credit',
  deadline: 'Due Mar 10',
  status: 'open'
}];
export const sampleCalendarEvents: CalendarEvent[] = [{
  id: '1',
  title: 'General Meeting',
  date: 'Mar 3',
  dayOfWeek: 'Friday',
  time: '6:00 PM',
  endTime: '7:30 PM',
  location: 'Boelter Hall 3400',
  building: 'UCLA Engineering',
  organizer: 'Jordan Lee',
  organizerInitials: 'JL',
  organizerColor: '#F97316',
  type: 'meeting',
  description: 'Monthly general meeting. Agenda: Spring Showcase budget vote, project lead assignments, and open Q&A.',
  color: '#FB7185'
}, {
  id: '2',
  title: 'Flyer Design Deadline',
  date: 'Mar 7',
  dayOfWeek: 'Thursday',
  time: '11:59 PM',
  endTime: '11:59 PM',
  location: 'Submit via Club Portal',
  building: 'Online',
  organizer: 'Alex Chen',
  organizerInitials: 'AC',
  organizerColor: '#8B5CF6',
  type: 'deadline',
  description: 'All Spring Showcase flyer submissions must be uploaded to the club portal by midnight.',
  color: '#FB7185'
}, {
  id: '3',
  title: 'Spring Showcase',
  date: 'Mar 10',
  dayOfWeek: 'Sunday',
  time: '2:00 PM',
  endTime: '6:00 PM',
  location: 'Ackerman Grand Ballroom',
  building: 'UCLA Ackerman Union',
  organizer: 'Jordan Lee',
  organizerInitials: 'JL',
  organizerColor: '#F97316',
  type: 'showcase',
  description: 'Annual end-of-year showcase. Members present their projects to peers, faculty, and industry guests. Attendance strongly encouraged.',
  color: '#FB7185'
}, {
  id: '4',
  title: 'Officer Elections',
  date: 'Mar 15',
  dayOfWeek: 'Friday',
  time: '5:00 PM',
  endTime: '6:30 PM',
  location: 'Bunche Hall 2209A',
  building: 'UCLA Bunche Hall',
  organizer: 'Maya Patel',
  organizerInitials: 'MP',
  organizerColor: '#10B981',
  type: 'election',
  description: "Vote for next semester's officers. All active members are eligible to vote. Candidates will give 2-minute speeches before the vote.",
  color: '#FB7185'
}];
const urgencyRowConfig = {
  urgent: {
    dot: '#dc2626',
    icon: <AlertCircleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />,
    color: '#dc2626',
    bg: '#fee2e2'
  },
  important: {
    dot: '#f59e0b',
    icon: <AlertTriangleIcon className="w-3.5 h-3.5" strokeWidth={2.5} />,
    color: '#b45309',
    bg: '#fef3c7'
  },
  info: {
    dot: '#2B7FE0',
    icon: <InfoIcon className="w-3.5 h-3.5" strokeWidth={2.5} />,
    color: '#2B7FE0',
    bg: '#e8f0fb'
  }
};
const statusBadge = (status: Project['status']) => {
  if (status === 'Completed') return {
    bg: '#e8f4ea',
    text: '#3a8c50',
    icon: <CheckCircleIcon className="w-3 h-3" strokeWidth={2.5} />
  };
  if (status === 'In Progress') return {
    bg: '#e8f0fb',
    text: '#2B7FE0',
    icon: <ClockIcon className="w-3 h-3" strokeWidth={2.5} />
  };
  return {
    bg: '#fef3c7',
    text: '#b45309',
    icon: <LightbulbIcon className="w-3 h-3" strokeWidth={2.5} />
  };
};
interface AllInboxesScreenProps {
  onBack?: () => void;
  onViewMember?: (member: Member) => void;
  onViewProject?: (project: Project) => void;
  onViewAnnouncement?: (announcement: Announcement) => void;
  onViewPosting?: (posting: Posting) => void;
  onViewCalendarEvent?: (event: CalendarEvent) => void;
}
export function AllInboxesScreen({
  onBack,
  onViewMember,
  onViewProject,
  onViewAnnouncement,
  onViewPosting,
  onViewCalendarEvent
}: AllInboxesScreenProps) {
  const [activeTab, setActiveTab] = useState<FilterTab>('members');
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const tabsScrollRef = useRef<HTMLDivElement>(null);
  const createOptions = [{
    id: 'member',
    label: 'New Member',
    icon: <UserIcon className="w-4 h-4" strokeWidth={2} />,
    color: '#8B5CF6',
    bg: '#EDE9FE'
  }, {
    id: 'project',
    label: 'New Project',
    icon: <BriefcaseIcon className="w-4 h-4" strokeWidth={2} />,
    color: '#06B6D4',
    bg: '#CFFAFE'
  }, {
    id: 'announcement',
    label: 'New Announcement',
    icon: <BellIcon className="w-4 h-4" strokeWidth={2} />,
    color: '#F97316',
    bg: '#FFEDD5'
  }, {
    id: 'posting',
    label: 'New Posting',
    icon: <ClipboardListIcon className="w-4 h-4" strokeWidth={2} />,
    color: '#10B981',
    bg: '#D1FAE5'
  }, {
    id: 'calendar',
    label: 'New Calendar Event',
    icon: <CalendarIcon className="w-4 h-4" strokeWidth={2} />,
    color: '#FB7185',
    bg: '#FFE4E6'
  }];
  useEffect(() => {
    if (!tabsScrollRef.current) return;
    const activeIndex = tabs.findIndex((t) => t.id === activeTab);
    const container = tabsScrollRef.current;
    const buttons = container.querySelectorAll('button');
    if (buttons[activeIndex]) {
      buttons[activeIndex].scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center'
      });
    }
  }, [activeTab]);
  return <div className="flex items-center justify-center min-h-screen" style={{
    backgroundColor: '#E8EAED'
  }}>
      <div className="relative flex flex-col overflow-hidden" style={{
      width: '390px',
      height: '844px',
      borderRadius: '44px',
      boxShadow: '0 30px 80px rgba(0,0,0,0.25)',
      backgroundColor: '#FFFFFF'
    }}>
        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-4 pb-1" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <span className="text-[17px] font-semibold text-gray-900 tracking-tight">
            5:58
          </span>
          <div className="flex items-center gap-1.5">
            <div className="flex items-end gap-[2px] h-4">
              <div className="w-[3px] h-[5px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[7px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[9px] bg-gray-800 rounded-sm" />
              <div className="w-[3px] h-[11px] bg-gray-300 rounded-sm" />
            </div>
            <svg className="w-4 h-4 text-gray-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M1.5 8.5a13 13 0 0121 0M5 12a10 10 0 0114 0M8.5 15.5a6 6 0 017 0M12 19h.01" />
            </svg>
            <div className="flex items-center gap-0.5">
              <div className="relative w-7 h-[14px] border-2 border-gray-800 rounded-[3px]">
                <div className="absolute inset-[1px] right-[3px] bg-gray-800 rounded-[1px]" />
                <span className="absolute inset-0 flex items-center justify-center text-[8px] font-bold text-white z-10">
                  45
                </span>
              </div>
              <div className="w-[2px] h-[6px] bg-gray-800 rounded-r-sm" />
            </div>
          </div>
        </div>

        {/* Navigation Bar */}
        <div className="flex items-center justify-between px-4 py-2" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <button className="w-11 h-11 rounded-full border border-gray-300 bg-white flex items-center justify-center shadow-sm" aria-label="Go back" onClick={onBack}>
            <ChevronLeftIcon className="w-5 h-5 text-gray-700" strokeWidth={2} />
          </button>
          <div className="flex items-center gap-3">
            <button className="w-11 h-11 rounded-full border border-gray-300 bg-white flex items-center justify-center shadow-sm transition-colors" aria-label="Create new item" onClick={() => setShowCreateMenu((v) => !v)} style={{
            backgroundColor: showCreateMenu ? '#1A1D23' : 'white'
          }}>
              {showCreateMenu ? <XIcon className="w-5 h-5 text-white" strokeWidth={2} /> : <PlusIcon className="w-5 h-5 text-gray-700" strokeWidth={2} />}
            </button>
          </div>
        </div>

        {/* Title Section */}
        <div className="px-5 pt-3 pb-4" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <h1 className="text-[34px] font-bold leading-tight tracking-tight" style={{
          color: '#1A1D23'
        }}>
            Media Creative Society
          </h1>
          <p className="text-[15px] mt-0.5" style={{
          color: '#9CA3AF'
        }}>
            Updated Just Now
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="pb-4" style={{
        backgroundColor: '#F0F2F5'
      }}>
          <div ref={tabsScrollRef} className="flex items-center gap-3 overflow-x-auto px-4" style={{
          scrollbarWidth: 'none',
          msOverflowStyle: 'none'
        } as React.CSSProperties}>
            {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return <button key={tab.id} onClick={() => setActiveTab(tab.id)} className="flex-shrink-0 flex items-center gap-2 px-4 py-3 rounded-full transition-all duration-200" style={{
              backgroundColor: isActive ? tab.activeColor : '#E8EAED'
            }} aria-label={tab.label} aria-pressed={isActive}>
                  <span style={{
                color: isActive ? 'white' : '#6b7280'
              }}>
                    {tab.icon}
                  </span>
                  <span className="text-[15px] font-semibold" style={{
                color: isActive ? 'white' : '#6b7280'
              }}>
                    {tab.label}
                  </span>
                </button>;
          })}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto" style={{
        backgroundColor: '#F8F9FA'
      }}>
          {/* MEMBERS */}
          {activeTab === 'members' && <div>
              <div className="px-5 pt-4 pb-2">
                <p className="text-[13px] font-medium text-gray-400 uppercase tracking-wide">
                  Club Members
                </p>
              </div>
              <div className="border-t border-gray-200" />
              {sampleMembers.map((member) => <button key={member.id} onClick={() => onViewMember?.(member)} className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0">
                  <div className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0" style={{
              backgroundColor: member.avatarColor
            }}>
                    <span className="text-[15px] font-bold text-white">
                      {member.avatarInitials}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="text-[16px] font-semibold text-gray-900 truncate">
                      {member.name}
                    </p>
                    <p className="text-[13px] text-gray-400 truncate">
                      {member.role}
                    </p>
                  </div>
                  <ChevronRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2.5} />
                </button>)}
            </div>}

          {/* PROJECTS */}
          {activeTab === 'projects' && <div>
              <div className="px-5 pt-4 pb-2">
                <p className="text-[13px] font-medium text-gray-400 uppercase tracking-wide">
                  Club Portfolio
                </p>
              </div>
              <div className="border-t border-gray-200" />
              {sampleProjects.map((project) => {
            const badge = statusBadge(project.status);
            return <button key={project.id} onClick={() => onViewProject?.(project)} className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{
                backgroundColor: project.leadAvatarColor + '20'
              }}>
                      <BriefcaseIcon className="w-5 h-5" style={{
                  color: project.leadAvatarColor
                }} strokeWidth={1.8} />
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-[16px] font-semibold text-gray-900 truncate">
                        {project.name}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold" style={{
                    backgroundColor: badge.bg,
                    color: badge.text
                  }}>
                          {badge.icon}
                          {project.status}
                        </span>
                        <span className="text-[12px] text-gray-400">
                          {project.leadMember}
                        </span>
                      </div>
                    </div>
                    <ChevronRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2.5} />
                  </button>;
          })}
            </div>}

          {/* ANNOUNCEMENTS */}
          {activeTab === 'announcements' && <div>
              <div className="px-5 pt-4 pb-2">
                <p className="text-[13px] font-medium text-gray-400 uppercase tracking-wide">
                  Recent Announcements
                </p>
              </div>
              <div className="border-t border-gray-200" />
              {sampleAnnouncements.map((ann, index) => {
            const urg = urgencyRowConfig[ann.urgency];
            const isUnread = index === 0;
            return <button key={ann.id} onClick={() => onViewAnnouncement?.(ann)} className="w-full flex items-start gap-0 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0">
                    <div className="w-1 self-stretch rounded-l-sm flex-shrink-0" style={{
                backgroundColor: urg.dot
              }} />
                    <div className="flex items-start gap-3 px-4 py-4 flex-1 min-w-0">
                      <div className="relative flex-shrink-0 mt-0.5">
                        <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{
                    backgroundColor: ann.senderColor
                  }}>
                          <span className="text-[12px] font-bold text-white">
                            {ann.senderInitials}
                          </span>
                        </div>
                        {isUnread && <div className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white" style={{
                    backgroundColor: '#FF2D78'
                  }} />}
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <div className="flex items-center justify-between mb-1">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold" style={{
                      backgroundColor: urg.bg,
                      color: urg.color
                    }}>
                            {urg.icon}
                            {ann.urgency.charAt(0).toUpperCase() + ann.urgency.slice(1)}
                          </span>
                          <span className="text-[12px] text-gray-400 ml-2 flex-shrink-0">
                            {ann.date.split(',')[0]}
                          </span>
                        </div>
                        <p className={`text-[15px] leading-snug line-clamp-2 mb-1 ${isUnread ? 'font-bold text-gray-900' : 'font-semibold text-gray-700'}`}>
                          {ann.title}
                        </p>
                        <div className="flex items-center gap-2">
                          <span className="text-[12px] text-gray-400">
                            {ann.sender}
                          </span>
                          <span className="text-gray-300">·</span>
                          <span className="text-[12px] text-gray-400">
                            {ann.readReceipts.length}/{ann.totalMembers} read
                          </span>
                        </div>
                      </div>
                      <ChevronRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0 mt-1" strokeWidth={2.5} />
                    </div>
                  </button>;
          })}
            </div>}

          {/* POSTINGS */}
          {activeTab === 'postings' && <div>
              <div className="px-5 pt-4 pb-2">
                <p className="text-[13px] font-medium text-gray-400 uppercase tracking-wide">
                  Open Roles & Gigs
                </p>
              </div>
              <div className="border-t border-gray-200" />
              {samplePostings.map((posting) => {
            const urg = urgencyRowConfig[posting.urgency];
            return <button key={posting.id} onClick={() => onViewPosting?.(posting)} className="w-full flex items-start gap-0 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0">
                    <div className="w-1 self-stretch flex-shrink-0" style={{
                backgroundColor: urg.dot
              }} />
                    <div className="flex items-center gap-3 px-4 py-4 flex-1 min-w-0">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{
                  backgroundColor: '#D1FAE5'
                }}>
                        <ClipboardListIcon className="w-5 h-5" style={{
                    color: '#10B981'
                  }} strokeWidth={1.8} />
                      </div>
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-[15px] font-semibold text-gray-900 truncate">
                          {posting.title}
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold" style={{
                      backgroundColor: urg.bg,
                      color: urg.color
                    }}>
                            {urg.icon}
                            {posting.urgency === 'urgent' ? 'Urgent' : posting.urgency === 'important' ? 'Important' : 'Open'}
                          </span>
                          <span className="text-[12px] text-gray-400">
                            {posting.deadline}
                          </span>
                        </div>
                      </div>
                      <ChevronRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2.5} />
                    </div>
                  </button>;
          })}
            </div>}

          {/* CALENDAR */}
          {activeTab === 'calendar' && <div>
              <div className="px-5 pt-4 pb-2">
                <p className="text-[13px] font-medium text-gray-400 uppercase tracking-wide">
                  Club Calendar
                </p>
              </div>
              <div className="border-t border-gray-200" />
              {sampleCalendarEvents.map((event) => <button key={event.id} onClick={() => onViewCalendarEvent?.(event)} className="w-full flex items-center gap-3 px-4 py-4 hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0">
                  <div className="w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 shadow-sm border border-gray-100">
                    <div className="h-3 w-full" style={{
                backgroundColor: event.color
              }} />
                    <div className="flex items-center justify-center h-9 bg-white">
                      <span className="text-[16px] font-bold text-gray-900 leading-none">
                        {event.date.split(' ')[1]}
                      </span>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="text-[15px] font-semibold text-gray-900 truncate">
                      {event.title}
                    </p>
                    <p className="text-[12px] text-gray-400">
                      {event.dayOfWeek} · {event.time} ·{' '}
                      {event.location.split(' ').slice(0, 2).join(' ')}
                    </p>
                  </div>
                  <ChevronRightIcon className="w-4 h-4 text-gray-400 flex-shrink-0" strokeWidth={2.5} />
                </button>)}
            </div>}
        </div>

        {/* Create Menu Overlay */}
        {showCreateMenu && <>
            {/* Backdrop */}
            <div className="absolute inset-0 z-20" style={{
          borderRadius: '44px',
          backgroundColor: 'rgba(0,0,0,0.25)'
        }} onClick={() => setShowCreateMenu(false)} />
            {/* Dropdown card */}
            <div className="absolute z-30 right-4" style={{
          top: '108px'
        }}>
              <div className="bg-white rounded-2xl overflow-hidden" style={{
            width: '220px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.18)'
          }}>
                <div className="px-4 pt-3 pb-2">
                  <p className="text-[11px] font-semibold uppercase tracking-widest text-gray-400">
                    Create New
                  </p>
                </div>
                <div className="border-t border-gray-100" />
                {createOptions.map((opt, index) => <div key={opt.id}>
                    <button className="w-full flex items-center gap-3 px-4 py-3.5 active:bg-gray-50 transition-colors text-left" onClick={() => setShowCreateMenu(false)}>
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{
                  backgroundColor: opt.bg
                }}>
                        <span style={{
                    color: opt.color
                  }}>
                          {opt.icon}
                        </span>
                      </div>
                      <span className="text-[15px] font-medium text-gray-900">
                        {opt.label}
                      </span>
                    </button>
                    {index < createOptions.length - 1 && <div className="border-t border-gray-100 mx-4" />}
                  </div>)}
              </div>
            </div>
          </>}
      </div>
    </div>;
}